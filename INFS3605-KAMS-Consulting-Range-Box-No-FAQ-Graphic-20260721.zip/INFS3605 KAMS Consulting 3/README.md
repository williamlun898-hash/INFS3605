# HealthBuddy FH Referral Prototype

High-fidelity mobile web prototype extending the SingHealth HealthBuddy experience for Familial Hypercholesterolaemia (FH) referral journeys.

## What It Includes

- SingPass-style login
- Focused HealthBuddy-style FH home screen
- Inbox and push notification simulation
- LDL range indicator that does not imply an exact patient value
- Three separate prototype logins covering red, yellow, and green result journeys
- Result-personalised FH FAQs that expand without moving the reader back to the top
- FH brochure translated into English, Chinese, and Malay
- FH risk prompt when the mock LDL result is above 5.5 mmol/L
- Working GP clinic search, phone links, directions, and information controls
- Account-specific saved progress after GP and GAC calls
- Simulated GP referral email
- 3-day GAC contact check notification
- Nearest GAC map with working locations, opening hours, phone links, directions, and information controls
- Contact confirmation that completes the referral follow-up loop
- Mock JSON data and sample Excel workbook

## Prototype Logins

Marker login details and the suggested test path are in `YENNI_MARKING_INSTRUCTIONS.txt`. They are intentionally not displayed inside the patient-facing prototype.

## Run Locally

Open `index.html` directly in a browser, or serve the folder with any static server.

Example:

```bash
python -m http.server 4173
```

Then visit:

```text
http://127.0.0.1:4173/index.html
```

## GitHub Pages

This project is static HTML, CSS, and JavaScript, so it can be published with GitHub Pages.

Use `index.html` as the entry point.

## Mock Data

The app uses:

- `data/patient.json`
- `data/clinics.json`
- `data/gacs.json`
- `data/sample_blood_tests.xlsx`

The LDL indicator reads the signed-in mock patient's result only to select the green, yellow, or red range. It does not display or point to an exact value. The prototype does not schedule GAC appointments or claim live integration with a GAC practice-management system.
