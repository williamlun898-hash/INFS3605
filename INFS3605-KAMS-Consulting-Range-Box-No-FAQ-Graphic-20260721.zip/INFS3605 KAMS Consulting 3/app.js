(function () {
  const fallbackData = {
    defaultPatientId: "red",
    patients: [
      {
        id: "red",
        name: "John Tan",
        patientId: "S1234567A",
        bloodTest: { date: "2026-06-12", ldl: 6.2 },
      },
      {
        id: "yellow",
        name: "Mary Lim",
        patientId: "S2345678B",
        bloodTest: { date: "2026-06-12", ldl: 5.1 },
      },
      {
        id: "green",
        name: "David Lee",
        patientId: "S4567890C",
        bloodTest: { date: "2026-06-12", ldl: 3.8 },
      },
    ],
    clinics: [
      {
        id: "c1",
        name: "Tampines Family Medical Clinic",
        distance: 0.7,
        phone: "+65 6781 2200",
        position: [64, 27],
        hours: "Mon-Fri 8:00 AM-5:30 PM; Sat 8:30 AM-12:30 PM",
        availability: "FH referral reviews before 4:00 PM on weekdays",
        notes: "Call ahead for cholesterol and family-history review appointments",
      },
      {
        id: "c2",
        name: "EastCare GP Clinic",
        distance: 1.1,
        phone: "+65 6788 1040",
        position: [34, 38],
        hours: "Mon-Fri 9:00 AM-6:00 PM; Sat 9:00 AM-1:00 PM",
        availability: "Next GP review window: this afternoon",
        notes: "Teleconsult follow-up available after the first visit",
      },
      {
        id: "c3",
        name: "Bedok Central Medical",
        distance: 1.6,
        phone: "+65 6442 8890",
        position: [72, 58],
        hours: "Mon-Fri 8:30 AM-8:00 PM; Sat-Sun 9:00 AM-12:00 PM",
        availability: "Same-day referral review if submitted before 3:30 PM",
        notes: "Directions open the nearest entrance for mobility access",
      },
      {
        id: "c4",
        name: "Healthway Family Clinic",
        distance: 2.0,
        phone: "+65 6245 5531",
        position: [43, 70],
        hours: "Mon-Fri 8:00 AM-7:00 PM; Sat 8:00 AM-2:00 PM",
        availability: "FH referral nurse callback within 1 working day",
        notes: "Bring existing medicines or previous lipid results if available",
      },
      {
        id: "c5",
        name: "Sunrise GP Partners",
        distance: 2.4,
        phone: "+65 6636 7720",
        position: [22, 64],
        hours: "Mon-Fri 9:00 AM-5:00 PM; closed weekends",
        availability: "Referral reviews every weekday morning",
        notes: "Clinic can request family screening guidance after GP review",
      },
    ],
    gacs: [
      {
        id: "gac1",
        name: "National Heart Centre Singapore GAC",
        distance: 6.2,
        phone: "+65 6704 8000",
        position: [62, 30],
        hours: "Mon-Fri 8:30 AM-5:30 PM",
        contact: "Call the centre to confirm referral requirements and current availability",
        notes: "Bring the GP referral email and latest blood test result",
      },
      {
        id: "gac2",
        name: "Singapore General Hospital GAC",
        distance: 6.8,
        phone: "+65 6321 4377",
        position: [38, 45],
        hours: "Mon-Fri 8:00 AM-5:00 PM",
        contact: "Call the centre for current clinic availability and instructions",
        notes: "Have your referral email and family history information ready",
      },
      {
        id: "gac3",
        name: "Changi General Hospital GAC",
        distance: 8.4,
        phone: "+65 6850 3333",
        position: [72, 62],
        hours: "Mon-Fri 8:30 AM-5:00 PM",
        contact: "Call the centre to discuss the next available assessment",
        notes: "Suitable if you prefer an east-side clinic location",
      },
    ],
  };

  const state = {
    route: "splash",
    history: [],
    data: fallbackData,
    notificationVisible: false,
    inboxUnread: true,
    openFaq: null,
    selectedPatientId: "red",
    progress: { stage: "none" },
    language: "en",
    consent: false,
    clinicSearch: "",
    selectedClinicId: "c1",
    openClinicInfoId: null,
    selectedGacId: "gac1",
    openGacInfoId: null,
  };

  const demoAccounts = {
    john: { patientId: "red", password: "1234" },
    mary: { patientId: "yellow", password: "1234" },
    david: { patientId: "green", password: "1234" },
  };

  const app = document.getElementById("app");

  const faqTitles = [
    "Short- and long-term consequences",
    "Cost information",
    "Family impact",
    "What happens next?",
    "Why early testing saves lives",
  ];

  const faqBodies = {
    red: [
      "High LDL often causes no immediate symptoms. Over time, untreated high LDL can contribute to cholesterol build-up in the arteries and increase the chance of heart disease at a younger age. Your result needs timely GP review.",
      "Consultation, counselling and genetic-testing costs can vary by provider and subsidy eligibility. Ask your GP or GAC to explain the current charges before you proceed; this prototype does not estimate a personal fee.",
      "FH can run in families. If FH is confirmed, close relatives may also be at risk and a genetic counsellor can explain who should consider screening.",
      "Ask your GP for an FH referral. When the referral is returned, use the GAC list to call a centre and confirm its process, opening hours and required documents.",
      "Early assessment can lead to earlier treatment and help identify relatives who may share the same inherited risk before serious symptoms develop.",
    ],
    yellow: [
      "This borderline result does not diagnose FH and does not trigger an urgent referral in this prototype. Continue routine care and discuss repeat testing, other risk factors and family history with your GP.",
      "No genetic test is being recommended automatically from this result. If your GP recommends further review, ask the clinic to explain consultation costs, testing charges and available subsidies first.",
      "A borderline result alone does not show that a condition is inherited. Tell your GP about early heart disease or very high cholesterol in close relatives so it can be considered properly.",
      "Keep following your GP's cholesterol plan. Seek a review if your result rises, your family history changes, or your clinician recommends further assessment.",
      "Regular monitoring helps identify changes early. Acting on future clinical advice can reduce long-term cardiovascular risk without causing unnecessary alarm now.",
    ],
    green: [
      "This result is within the target range used by the prototype and does not trigger an FH referral prompt. Continue normal preventive care and follow your clinician's advice.",
      "No FH genetic-testing cost is indicated by this result alone. If testing is later recommended because of family history or another clinical factor, confirm current fees and subsidies with the provider.",
      "A result in this range does not rule out every inherited risk. Share any strong family history of early heart disease or very high cholesterol with your GP during routine care.",
      "No FH referral action is prompted. Continue routine cholesterol monitoring, prescribed treatment and healthy habits recommended by your clinician.",
      "Routine screening helps keep risk visible over time. Early GP review remains important if future results rise or new family-history information becomes available.",
    ],
  };

  const brochureCopy = {
    en: {
      language: "English",
      title: "Familial Hypercholesterolaemia (FH)",
      intro: "FH is an inherited condition that can cause high LDL cholesterol from a young age, even when a person feels healthy.",
      whyTitle: "Why it matters",
      why: "Without appropriate care, lifelong high LDL can increase the risk of early heart disease. A GP considers the result together with family history, age, medicines and other clinical factors.",
      familyTitle: "What it means for family",
      family: "If FH is confirmed, close relatives may also be at risk. A genetic counsellor can explain family screening without the app contacting relatives automatically.",
      actionTitle: "Your next step",
    },
    zh: {
      language: "中文",
      title: "家族性高胆固醇血症 (FH)",
      intro: "FH 是一种遗传性疾病，可使人从年轻时起就有较高的低密度脂蛋白胆固醇，即使本人没有明显症状。",
      whyTitle: "为什么需要关注",
      why: "如果长期高胆固醇没有得到适当管理，较早发生心血管疾病的风险可能增加。医生会结合家族史、年龄、药物和其他临床因素作出判断。",
      familyTitle: "对家人的意义",
      family: "如果确认患有 FH，近亲也可能有相关风险。遗传咨询人员会说明家族筛查；本应用不会自动联系您的家人。",
      actionTitle: "下一步",
    },
    ms: {
      language: "Bahasa Melayu",
      title: "Hiperkolesterolemia Familial (FH)",
      intro: "FH ialah keadaan keturunan yang boleh menyebabkan kolesterol LDL tinggi sejak usia muda walaupun seseorang berasa sihat.",
      whyTitle: "Mengapa ia penting",
      why: "Tanpa penjagaan yang sesuai, LDL tinggi sepanjang hayat boleh meningkatkan risiko penyakit jantung pada usia lebih muda. GP akan menilai keputusan bersama sejarah keluarga, umur, ubat dan faktor klinikal lain.",
      familyTitle: "Kesan kepada keluarga",
      family: "Jika FH disahkan, saudara terdekat juga mungkin berisiko. Kaunselor genetik boleh menerangkan saringan keluarga tanpa aplikasi menghubungi ahli keluarga secara automatik.",
      actionTitle: "Langkah seterusnya",
    },
  };

  const messages = [
    {
      id: "blood",
      title: "Blood Test Results Ready",
      subtitle: "Your blood test results are now available.",
      unread: true,
    },
  ];

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function formatDate(value) {
    return new Intl.DateTimeFormat("en-SG", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(value));
  }

  function phoneHref(phone) {
    return `tel:${String(phone).replace(/[^+\d]/g, "")}`;
  }

  function directionsHref(name) {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${name}, Singapore`)}`;
  }

  function ldlBand(ldl) {
    if (ldl < 5) return { label: "Within target", className: "green", color: "var(--hb-green)" };
    if (ldl <= 5.5) return { label: "Borderline", className: "yellow", color: "var(--hb-yellow)" };
    return { label: "High range", className: "red", color: "var(--hb-red)" };
  }

  function currentPatient() {
    const patients = state.data.patients || fallbackData.patients;
    return patients.find((patient) => patient.id === state.selectedPatientId) || patients[0];
  }

  function currentFaqItems(patient) {
    const band = ldlBand(patient.bloodTest.ldl).className;
    return faqTitles.map((title, index) => ({ title, body: faqBodies[band][index] }));
  }

  function progressStorageKey(patientId) {
    return `healthbuddy-fh-progress-${patientId}`;
  }

  function loadProgress(patientId) {
    try {
      const saved = window.localStorage.getItem(progressStorageKey(patientId));
      const progress = saved ? JSON.parse(saved) : null;
      return progress?.stage ? progress : { stage: "none" };
    } catch (_) {
      return { stage: "none" };
    }
  }

  function saveProgress(stage, details = {}) {
    state.progress = {
      ...state.progress,
      ...details,
      stage,
      updatedAt: new Date().toISOString(),
    };
    try {
      window.localStorage.setItem(progressStorageKey(state.selectedPatientId), JSON.stringify(state.progress));
    } catch (_) {
      // In-memory progress still works when browser storage is unavailable.
    }
  }

  function workflowProgressCard() {
    const progress = state.progress || { stage: "none" };
    if (progress.stage === "none") return "";

    const clinic = (state.data.clinics || []).find((item) => item.id === progress.clinicId);
    const gac = (state.data.gacs || []).find((item) => item.id === progress.gacId);
    const stages = {
      "gp-called": {
        title: "GP call saved",
        body: `You called ${clinic?.name || "your GP clinic"}. Continue here when your referral email arrives.`,
        done: ["Blood Result Scanned", "GP Called"],
        pending: ["Referral Email Received", "Contact a GAC"],
        route: "find-gp",
        action: "Continue referral confirmation",
      },
      "referral-received": {
        title: "Referral email received",
        body: "Your GP referral is ready. Continue to the GAC contact information without repeating earlier steps.",
        done: ["Blood Result Scanned", "GP Called", "Referral Email Received"],
        pending: ["Contact a GAC"],
        route: "gp-referral-email",
        action: "Continue to GAC contacts",
      },
      "gac-called": {
        title: "GAC call saved",
        body: `You called ${gac?.name || "a Genetic Assessment Clinic"}. Confirm the contact when you return.`,
        done: ["Blood Result Scanned", "GP Called", "Referral Email Received", "GAC Called"],
        pending: ["Confirm GAC Contact"],
        route: "find-gac",
        action: "Confirm GAC contact",
      },
      complete: {
        title: "Referral follow-up complete",
        body: "Your GP referral and GAC contact steps are recorded as complete.",
        done: ["Blood Result Scanned", "GP Called", "Referral Email Received", "GAC Contact Confirmed"],
        pending: [],
        route: "self-booked-complete",
        action: "View completed journey",
      },
    };
    const copy = stages[progress.stage];
    if (!copy) return "";

    return `
      <section class="workflow-progress">
        <div class="workflow-progress-heading">
          <span class="progress-icon">FH</span>
          <span><small>Saved progress</small><strong>${escapeHtml(copy.title)}</strong></span>
        </div>
        <p>${escapeHtml(copy.body)}</p>
        ${timeline(copy.done, copy.pending)}
        <button class="primary full" data-route="${copy.route}">${escapeHtml(copy.action)}</button>
      </section>
    `;
  }

  function languageSwitcher() {
    const languages = [
      ["en", "English"],
      ["zh", "中文"],
      ["ms", "Bahasa Melayu"],
    ];
    return `
      <div class="language-switcher" aria-label="Brochure language">
        ${languages
          .map(([code, label]) => `<button class="language-button ${state.language === code ? "active" : ""}" data-language="${code}">${label}</button>`)
          .join("")}
      </div>
    `;
  }

  function clinicMeta(clinic) {
    return {
      hours: clinic.hours || "Mon-Fri 9:00 AM-5:00 PM",
      availability: clinic.availability || "Referral review available on weekdays",
      notes: clinic.notes || "Call the clinic before visiting for the latest appointment availability",
    };
  }

  function gacMeta(gac) {
    return {
      hours: gac.hours || "Mon-Fri 9:00 AM-5:00 PM",
      contact: gac.contact || "Call the GAC for its current clinic process and availability",
      notes: gac.notes || "Have your GP referral email ready when you call",
    };
  }

  async function loadData() {
    try {
      const [patientResponse, clinicResponse, gacResponse] = await Promise.all([
        fetch("data/patient.json"),
        fetch("data/clinics.json"),
        fetch("data/gacs.json"),
      ]);
      if (!patientResponse.ok || !clinicResponse.ok || !gacResponse.ok) return;
      const [patientPayload, clinics, gacs] = await Promise.all([patientResponse.json(), clinicResponse.json(), gacResponse.json()]);
      const patients = patientPayload.patients || [patientPayload];
      state.data = { patients, clinics, gacs };
      state.selectedPatientId = patientPayload.defaultPatientId || patients[0].id;
    } catch (_) {
      state.data = fallbackData;
    }
  }

  function go(route, options = {}) {
    if (!options.replace) state.history.push(state.route);
    state.route = route;
    render();
  }

  function back() {
    state.route = state.history.pop() || "home";
    render();
  }

  function topbar(title, backEnabled = true, action = "") {
    return `
      <header class="topbar">
        ${
          backEnabled
            ? `<button class="back" data-action="back" aria-label="Go back">&lt;</button>`
            : `<span class="topbar-spacer"></span>`
        }
        <h1>${escapeHtml(title)}</h1>
        ${action || `<span class="topbar-spacer"></span>`}
      </header>
    `;
  }

  function healthBuddyLogo() {
    return `
      <span class="hb-logo-text" aria-label="HealthBuddy">
        <span class="health-word">Health</span><span class="buddy-word">Buddy</span>
      </span>
    `;
  }

  function splashScreen() {
    return `
      <section class="splash">
        <div class="splash-card">
          <div class="splash-app-icon">
            <span class="splash-heart"></span>
          </div>
          ${healthBuddyLogo()}
          <p>Your health is in your hands</p>
          <div class="singhealth-brand">SingHealth</div>
          <div class="hospital-grid" aria-label="SingHealth institutions">
            <span>Singapore General Hospital</span>
            <span>Changi General Hospital</span>
            <span>Sengkang General Hospital</span>
            <span>KK Women's and Children's Hospital</span>
            <span>National Heart Centre Singapore</span>
            <span>National Cancer Centre Singapore</span>
            <span>Singapore National Eye Centre</span>
            <span>SingHealth Polyclinics</span>
          </div>
          <div class="loader" aria-hidden="true"></div>
        </div>
      </section>
    `;
  }

  function loginScreen() {
    return `
      <section class="screen login-screen">
        <div class="login-hero">
          <div class="brand-row">
            <span class="singpass-mark">SP</span>
            <span>
              <span class="brand-title">SingPass</span>
              <span class="brand-subtitle">Secure access to HealthBuddy</span>
            </span>
          </div>
          <h1>Log in securely</h1>
          <p>Use your SingPass credentials to continue to SingHealth HealthBuddy.</p>
        </div>
        <div class="form-card">
          <div class="field">
            <label for="username">Username</label>
            <input id="username" autocomplete="username" placeholder="Enter username" />
          </div>
          <div class="field">
            <label for="password">Password</label>
            <input id="password" type="password" autocomplete="current-password" placeholder="Enter password" />
          </div>
          <p class="login-error" id="login-error" role="alert" hidden></p>
          <button class="primary full" data-action="login">Log in</button>
        </div>
      </section>
    `;
  }

  function homeScreen() {
    const patient = currentPatient();
    const band = ldlBand(patient.bloodTest.ldl);
    const notification = state.notificationVisible
      ? `
        <button class="notification pulse" data-route="inbox">
          <span class="notification-dot">!</span>
          <span>
            <strong>Your blood test results are now available.</strong>
            <span>Tap to open Inbox</span>
          </span>
        </button>
      `
      : "";
    const brochureSummary = {
      red: "Your result needs timely GP review. Learn why FH can affect long-term heart health and close relatives.",
      yellow: "Your result is borderline. Learn what to monitor and when family history may matter.",
      green: "Your result is within the prototype target range. Learn about FH and when to speak with your GP.",
    };
    const fhBrochure = `
        <section class="fh-brochure-card risk-${band.className}">
          <span class="fh-icon">FH</span>
          <span>
            <strong>FH information brochure</strong>
            <span>${escapeHtml(brochureSummary[band.className])}</span>
          </span>
          <button class="primary compact" data-route="fh-brochure">Read</button>
        </section>
      `;
    return `
      <section class="screen">
        <header class="home-header">
          <button class="inbox-shortcut ${state.inboxUnread ? "pulse" : ""}" data-route="inbox" aria-label="Inbox">
            <span class="line-icon" aria-hidden="true"></span>
            ${state.inboxUnread ? `<span class="badge">1</span>` : ""}
          </button>
          ${healthBuddyLogo()}
          <button class="login-link" data-action="logout">Log Out</button>
        </header>
        <div class="content home-content">
          ${notification}
          ${workflowProgressCard()}
          <section class="patient-result-summary risk-card-${band.className}">
            <span>
              <small>${escapeHtml(patient.name)}</small>
              <strong>Blood test result ready</strong>
              <span>${escapeHtml(brochureSummary[band.className])}</span>
            </span>
            <button class="primary full" data-route="results">View result</button>
          </section>
          ${fhBrochure}
        </div>
      </section>
    `;
  }

  function inboxScreen() {
    return `
      <section class="screen">
        ${topbar("Inbox", true)}
        <div class="content">
          <div class="section-title">
            <h2>Recent messages</h2>
            <span class="status-pill">Newest first</span>
          </div>
          ${messages
            .map((message) => {
              const unread = message.unread && state.inboxUnread;
              return `
                <button class="message-card ${unread ? "unread" : ""}" data-message="${message.id}">
                  <span class="${unread ? "unread-dot" : ""}"></span>
                  <span>
                    <strong>${escapeHtml(message.title)}</strong>
                    <span>${escapeHtml(message.subtitle)}</span>
                  </span>
                  ${unread ? `<span class="new-pill">NEW</span>` : `<span class="muted">&gt;</span>`}
                </button>
              `;
            })
            .join("")}
        </div>
      </section>
    `;
  }

  function resultsScreen() {
    const patient = currentPatient();
    const ldl = patient.bloodTest.ldl;
    const band = ldlBand(ldl);
    const shouldPromptReferral = ldl > 5.5;
    const faqItems = currentFaqItems(patient);
    const careCopy = {
      red: "Your result is above 5.5 mmol/L. Arrange a timely GP review and ask whether an FH referral is appropriate.",
      yellow: "Your result is borderline in this prototype. Continue routine care and discuss your full risk profile with your GP.",
      green: "Your result is within the prototype target range. No FH referral prompt is shown; continue routine preventive care.",
    };
    return `
      <section class="screen">
        ${topbar("Blood Test Results")}
        <div class="content ${shouldPromptReferral ? "results-content" : ""}">
          <div class="gauge-card risk-card-${band.className}">
            <div class="gauge-heading">
              <span>
                <h2>${escapeHtml(patient.name)}'s cholesterol indicator</h2>
                <p>Result date: ${formatDate(patient.bloodTest.date)}. HealthBuddy scans this against the FH referral threshold.</p>
              </span>
            </div>
            <div class="gauge" aria-label="LDL cholesterol visual indicator">
              <div class="gauge-track"><span></span><span></span><span></span></div>
              <div class="gauge-range-highlight ${band.className}" role="img" aria-label="Your result is in the ${escapeHtml(band.label.toLowerCase())} range"></div>
              <div class="gauge-scale">
                <span>0 mmol/L</span>
                <span>5.5+ mmol/L</span>
              </div>
            </div>
            <div class="care-note">
              ${escapeHtml(careCopy[band.className])}
            </div>
          </div>
          <div class="section-title">
            <h2>Understand your result</h2>
            <button class="see-all" data-route="fh-brochure">FH brochure</button>
          </div>
          ${faqItems.map((item, index) => faqCard(item, index)).join("")}
        </div>
        ${
          shouldPromptReferral
            ? `<div class="floating-referral"><button class="primary full" data-route="consent">Ask GP for Referral</button></div>`
            : ""
        }
      </section>
    `;
  }

  function faqCard(item, index) {
    const open = state.openFaq === index;
    return `
      <article class="faq-card ${open ? "open" : ""}">
        <button class="faq-toggle" data-faq="${index}" aria-expanded="${open}">
          <span class="faq-icon">i</span>
          <strong>${escapeHtml(item.title)}</strong>
          <span class="chevron">${open ? "-" : "+"}</span>
        </button>
        <div class="faq-body">
          <p>${escapeHtml(item.body)}</p>
          <button class="secondary" data-route="fh-brochure">Read FH brochure</button>
        </div>
      </article>
    `;
  }

  function fhBrochureScreen() {
    const patient = currentPatient();
    const band = ldlBand(patient.bloodTest.ldl);
    const copy = brochureCopy[state.language] || brochureCopy.en;
    const actionCopy = {
      en: {
        red: "Contact your GP promptly to review this result and ask whether an FH referral is appropriate.",
        yellow: "Continue routine care and discuss your cholesterol trend and family history with your GP.",
        green: "Continue routine preventive care and share any strong family history with your GP.",
      },
      zh: {
        red: "请尽快联系您的医生复查结果，并询问是否需要进行 FH 转诊。",
        yellow: "请继续常规护理，并与医生讨论胆固醇变化趋势及家族史。",
        green: "请继续常规预防护理，并向医生说明任何重要的家族病史。",
      },
      ms: {
        red: "Hubungi GP anda dengan segera untuk menyemak keputusan ini dan bertanya sama ada rujukan FH diperlukan.",
        yellow: "Teruskan penjagaan rutin dan bincangkan trend kolesterol serta sejarah keluarga dengan GP anda.",
        green: "Teruskan penjagaan pencegahan rutin dan maklumkan GP tentang sejarah keluarga yang penting.",
      },
    };
    return `
      <section class="screen">
        ${topbar("FH Brochure")}
        <div class="content no-tabs">
          ${languageSwitcher()}
          <article class="brochure-sheet risk-${band.className}">
            <div class="brochure-cover">
              <span class="fh-icon">FH</span>
              <span>
                <small>${escapeHtml(copy.language)}</small>
                <h2>${escapeHtml(copy.title)}</h2>
                <p>${escapeHtml(copy.intro)}</p>
              </span>
            </div>
            <div class="brochure-risk-row">
              <span class="risk-dot ${band.className}"></span>
              <span><strong>${escapeHtml(patient.name)}</strong><small>${escapeHtml(band.label)} prototype result</small></span>
            </div>
            <section class="brochure-section">
              <h3>${escapeHtml(copy.whyTitle)}</h3>
              <p>${escapeHtml(copy.why)}</p>
            </section>
            <section class="brochure-section">
              <h3>${escapeHtml(copy.familyTitle)}</h3>
              <p>${escapeHtml(copy.family)}</p>
            </section>
            <section class="brochure-section action">
              <h3>${escapeHtml(copy.actionTitle)}</h3>
              <p>${escapeHtml(actionCopy[state.language][band.className])}</p>
            </section>
          </article>
          <button class="primary full" data-route="results">View personalised result guidance</button>
        </div>
      </section>
    `;
  }

  function consentScreen() {
    return `
      <section class="screen">
        ${topbar("Share Blood Test Results")}
        <div class="content no-tabs">
          <div class="consent-box">
            <h2>Share Blood Test Results</h2>
            <p>
              By submitting this request, you authorise SingHealth to securely share your relevant laboratory results with your selected GP clinic through approved healthcare systems for clinical review.
            </p>
            <label class="check-row">
              <input type="checkbox" data-action="consent" ${state.consent ? "checked" : ""} />
              <span>I understand and consent.</span>
            </label>
            <button class="primary full" data-route="find-gp" ${state.consent ? "" : "disabled"}>Continue</button>
          </div>
        </div>
      </section>
    `;
  }

  function findGpScreen() {
    const clinics = state.data.clinics
      .slice()
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 5);
    const query = state.clinicSearch.trim().toLowerCase();
    const visibleClinics = clinics.filter((clinic) => `${clinic.name} ${clinic.phone}`.toLowerCase().includes(query));
    return `
      <section class="screen">
        ${topbar("Ask GP for Referral")}
        <div class="content no-tabs">
          <div class="care-note">
            Call your GP and ask for an FH testing referral. Once your GP emails the referral back to you, HealthBuddy can help you find and contact a Genetic Assessment Clinic.
          </div>
          ${
            state.progress.stage === "gp-called"
              ? `<div class="saved-call-note"><strong>GP call saved</strong><span>Your progress is saved. Use the confirmation below when the referral email arrives.</span></div>`
              : ""
          }
          <div class="field">
            <label for="clinic-search">Search GP clinic to call</label>
            <input id="clinic-search" class="search-input" value="${escapeHtml(state.clinicSearch)}" placeholder="Search by clinic name or phone" autocomplete="off" />
          </div>
          <div class="section-title">
            <h2>Nearby GP clinics</h2>
            <span class="muted">Nearest five</span>
          </div>
          <div class="map-card" aria-label="Interactive map with nearby GP pins">
            <span class="map-road one"></span>
            <span class="map-road two"></span>
            <span class="location-dot" title="Your location"></span>
            ${clinics
              .map(
                (clinic, index) => `
                  <button class="map-pin ${clinic.id === state.selectedClinicId ? "selected" : ""}" style="left:${clinic.position[0]}%;top:${clinic.position[1]}%" data-clinic="${clinic.id}" data-clinic-search="${escapeHtml(`${clinic.name} ${clinic.phone}`.toLowerCase())}" aria-label="${escapeHtml(clinic.name)}" ${visibleClinics.includes(clinic) ? "" : "hidden"}>
                    <span>${index + 1}</span>
                  </button>
                `,
              )
              .join("")}
          </div>
          <div id="gp-clinic-list">
            ${clinics.map((clinic) => clinicCard(clinic)).join("")}
            <p class="empty-search" id="clinic-search-empty" ${visibleClinics.length ? "hidden" : ""}>No matching GP clinics.</p>
          </div>
          <button class="primary full" data-action="referral-received">I received my referral email</button>
        </div>
      </section>
    `;
  }

  function clinicCard(clinic) {
    const selected = clinic.id === state.selectedClinicId;
    const detailsOpen = clinic.id === state.openClinicInfoId;
    const details = clinicMeta(clinic);
    const matchesSearch = `${clinic.name} ${clinic.phone}`.toLowerCase().includes(state.clinicSearch.trim().toLowerCase());
    return `
      <article class="clinic-card ${selected ? "selected" : ""}" data-clinic-search="${escapeHtml(`${clinic.name} ${clinic.phone}`.toLowerCase())}" ${matchesSearch ? "" : "hidden"}>
        <div class="clinic-top">
          <span>
            <h3>${escapeHtml(clinic.name)}</h3>
            <p>${clinic.distance.toFixed(1)} km away - ${escapeHtml(clinic.phone)}</p>
          </span>
          ${selected ? `<span class="status-pill">Chosen</span>` : ""}
        </div>
        <div class="clinic-actions">
          <a class="mini-button" href="${escapeHtml(phoneHref(clinic.phone))}" data-call-stage="gp" data-clinic="${clinic.id}" aria-label="Call ${escapeHtml(clinic.name)}">Call</a>
          <a class="mini-button" href="${escapeHtml(directionsHref(clinic.name))}" target="_blank" rel="noopener noreferrer" aria-label="Directions to ${escapeHtml(clinic.name)}">Directions</a>
          <button class="mini-button" data-action="clinic-info" data-clinic="${clinic.id}">${detailsOpen ? "Hide info" : "Info"}</button>
        </div>
        ${
          detailsOpen
            ? `<div class="clinic-details">
                <span><strong>Opening hours</strong>${escapeHtml(details.hours)}</span>
                <span><strong>Referral availability</strong>${escapeHtml(details.availability)}</span>
                <span><strong>Clinic note</strong>${escapeHtml(details.notes)}</span>
              </div>`
            : ""
        }
      </article>
    `;
  }

  function gpReferralEmailScreen() {
    return `
      <section class="screen">
        ${topbar("GP Referral Email")}
        <div class="content no-tabs">
          <div class="notification full">
            <span class="notification-dot">!</span>
            <span>
              <strong>Your GP has emailed your FH referral.</strong>
              <span>Referral ready for GAC contact</span>
            </span>
          </div>
          <div class="care-note">
            Use HealthBuddy to find nearby Genetic Assessment Clinics, then call the centre directly for its current process and availability.
          </div>
          ${timeline(["Blood Result Scanned", "GP Referral Requested", "Referral Email Received"], ["Contact a GAC"])}
          <button class="primary full" data-route="find-gac">View nearby GACs</button>
          <button class="secondary full" data-route="booking-check">Show 3-day contact check</button>
        </div>
      </section>
    `;
  }

  function bookingCheckScreen() {
    return `
      <section class="screen">
        ${topbar("GAC Contact Check")}
        <div class="content no-tabs">
          <div class="notification full">
            <span class="notification-dot">!</span>
            <span>
              <strong>Have you contacted a GAC?</strong>
              <span>Simulated 3-day phone notification</span>
            </span>
          </div>
          <div class="care-note">
            If you already called a GAC, confirm here and the app will close the loop. If not, HealthBuddy will show nearby centres with their contact details.
          </div>
          <div class="reminder-actions">
            <button class="primary" data-action="booking-check-yes">Yes</button>
            <button class="secondary" data-action="booking-check-no">No</button>
          </div>
        </div>
      </section>
    `;
  }

  function selfBookedCompleteScreen() {
    return `
      <section class="screen">
        <div class="success-panel">
          <div class="tick" aria-hidden="true"></div>
          <span>
            <h1>GAC Contact Confirmed</h1>
            <p>You confirmed that you contacted a Genetic Assessment Clinic directly. The referral follow-up loop is complete.</p>
          </span>
          ${timeline(["Blood Result Scanned", "GP Referral Requested", "Referral Email Received", "GAC Contact Confirmed"], [])}
          <button class="primary full" data-route="home">Back to Home</button>
        </div>
      </section>
    `;
  }

  function findGacScreen() {
    const gacs = (state.data.gacs || fallbackData.gacs)
      .slice()
      .sort((a, b) => a.distance - b.distance);
    return `
      <section class="screen">
        ${topbar("Find GAC")}
        <div class="content no-tabs">
          <div class="care-note">
            HealthBuddy does not schedule GAC appointments. Use the map and clinic cards below to check each location, opening hours and phone number, then call the centre directly.
          </div>
          ${
            state.progress.stage === "gac-called"
              ? `<div class="saved-call-note"><strong>GAC call saved</strong><span>Your progress is saved. Confirm the contact below to complete the referral follow-up.</span></div>`
              : ""
          }
          <div class="section-title">
            <h2>Nearby GAC locations</h2>
            <span class="muted">Nearest first</span>
          </div>
          <div class="map-card" aria-label="Interactive map with nearby GAC pins">
            <span class="map-road one"></span>
            <span class="map-road two"></span>
            <span class="location-dot" title="Your location"></span>
            ${gacs
              .map(
                (gac, index) => `
                  <button class="map-pin ${gac.id === state.selectedGacId ? "selected" : ""}" style="left:${gac.position[0]}%;top:${gac.position[1]}%" data-gac="${gac.id}" aria-label="${escapeHtml(gac.name)}">
                    <span>${index + 1}</span>
                  </button>
                `,
              )
              .join("")}
          </div>
          ${gacs.map((gac) => gacCentreCard(gac)).join("")}
          <button class="primary full" data-action="confirm-gac-contact">I have contacted a GAC</button>
        </div>
      </section>
    `;
  }

  function gacCentreCard(gac) {
    const selected = gac.id === state.selectedGacId;
    const detailsOpen = gac.id === state.openGacInfoId;
    const details = gacMeta(gac);
    return `
      <article class="clinic-card ${selected ? "selected" : ""}">
        <div class="clinic-top">
          <span>
            <h3>${escapeHtml(gac.name)}</h3>
            <p>${gac.distance.toFixed(1)} km away - ${escapeHtml(gac.phone)}</p>
          </span>
          ${selected ? `<span class="status-pill">Selected</span>` : ""}
        </div>
        <div class="clinic-actions">
          <a class="mini-button" href="${escapeHtml(phoneHref(gac.phone))}" data-call-stage="gac" data-gac="${gac.id}" aria-label="Call ${escapeHtml(gac.name)}">Call</a>
          <a class="mini-button" href="${escapeHtml(directionsHref(gac.name))}" target="_blank" rel="noopener noreferrer" aria-label="Directions to ${escapeHtml(gac.name)}">Directions</a>
          <button class="mini-button" data-action="gac-info" data-gac="${gac.id}">${detailsOpen ? "Hide info" : "Info"}</button>
        </div>
        ${
          detailsOpen
            ? `<div class="clinic-details">
                <span><strong>Opening hours</strong>${escapeHtml(details.hours)}</span>
                <span><strong>Contact guidance</strong>${escapeHtml(details.contact)}</span>
                <span><strong>Before you call</strong>${escapeHtml(details.notes)}</span>
              </div>`
            : ""
        }
      </article>
    `;
  }

  function timeline(doneItems, pendingItems) {
    return `
      <div class="timeline">
        ${doneItems
          .map(
            (item) => `
              <div class="timeline-item done">
                <span class="timeline-dot"></span>
                <span>${escapeHtml(item)}</span>
              </div>
            `,
          )
          .join("")}
        ${pendingItems
          .map(
            (item) => `
              <div class="timeline-item">
                <span class="timeline-dot"></span>
                <span>${escapeHtml(item)}</span>
              </div>
            `,
          )
          .join("")}
      </div>
    `;
  }

  function render() {
    const routes = {
      splash: splashScreen,
      login: loginScreen,
      home: homeScreen,
      inbox: inboxScreen,
      results: resultsScreen,
      "fh-brochure": fhBrochureScreen,
      consent: consentScreen,
      "find-gp": findGpScreen,
      "gp-referral-email": gpReferralEmailScreen,
      "booking-check": bookingCheckScreen,
      "self-booked-complete": selfBookedCompleteScreen,
      "find-gac": findGacScreen,
    };
    app.innerHTML = (routes[state.route] || homeScreen)();
  }

  function renderFaqWithoutJump(button) {
    const scroller = button.closest(".content");
    const previousScrollTop = scroller?.scrollTop || 0;
    const previousTop = button.getBoundingClientRect?.().top;
    const faqIndex = button.dataset.faq;

    render();

    const nextScroller = app.querySelector?.(".content");
    const nextButton = app.querySelector?.(`[data-faq="${faqIndex}"]`);
    if (!nextScroller) return;

    nextScroller.scrollTop = previousScrollTop;
    if (nextButton && Number.isFinite(previousTop)) {
      nextScroller.scrollTop += nextButton.getBoundingClientRect().top - previousTop;
    }
  }

  function showLoginError(message) {
    const error = document.getElementById("login-error");
    if (!error) return;
    error.textContent = message;
    error.hidden = false;
  }

  function login() {
    const username = document.getElementById("username")?.value.trim().toLowerCase() || "";
    const password = document.getElementById("password")?.value || "";
    const patients = state.data.patients || fallbackData.patients;
    const account = demoAccounts[username];
    const patient = account ? patients.find((candidate) => candidate.id === account.patientId) : null;

    if (!patient) {
      showLoginError("Username not recognised.");
      return;
    }

    if (account.password !== password) {
      showLoginError("Incorrect password.");
      return;
    }

    state.selectedPatientId = patient.id;
    state.progress = loadProgress(patient.id);
    state.openFaq = null;
    state.language = "en";
    state.consent = false;
    state.clinicSearch = "";
    state.notificationVisible = false;
    state.inboxUnread = true;
    state.history = [];
    state.route = "home";
    render();
    window.setTimeout(() => {
      state.notificationVisible = true;
      if (state.route === "home") render();
    }, 900);
  }

  app.addEventListener("click", (event) => {
    const callLink = event.target.closest("a[data-call-stage]");
    if (callLink) {
      if (callLink.dataset.callStage === "gp") {
        state.selectedClinicId = callLink.dataset.clinic;
        saveProgress("gp-called", { clinicId: callLink.dataset.clinic, gacId: null });
      } else if (callLink.dataset.callStage === "gac") {
        state.selectedGacId = callLink.dataset.gac;
        saveProgress("gac-called", { gacId: callLink.dataset.gac });
      }
      state.history = [];
      state.route = "home";
      render();
      return;
    }

    const target = event.target.closest("button");
    if (!target) return;

    if (target.dataset.action === "back") {
      back();
      return;
    }

    if (target.dataset.action === "login") {
      login();
      return;
    }

    if (target.dataset.action === "logout") {
      state.history = [];
      state.route = "login";
      state.notificationVisible = false;
      state.clinicSearch = "";
      state.progress = { stage: "none" };
      render();
      return;
    }

    if (target.dataset.message === "blood") {
      state.inboxUnread = false;
      go("results");
      return;
    }

    if (target.dataset.faq !== undefined) {
      const index = Number(target.dataset.faq);
      state.openFaq = state.openFaq === index ? null : index;
      renderFaqWithoutJump(target);
      return;
    }

    if (target.dataset.language) {
      state.language = target.dataset.language;
      render();
      return;
    }

    if (target.dataset.action === "referral-received") {
      saveProgress("referral-received");
      go("gp-referral-email");
      return;
    }

    if (target.dataset.action === "booking-check-yes") {
      saveProgress("complete");
      go("self-booked-complete");
      return;
    }

    if (target.dataset.action === "booking-check-no") {
      go("find-gac");
      return;
    }

    if (target.dataset.action === "confirm-gac-contact") {
      saveProgress("complete");
      go("self-booked-complete");
      return;
    }

    if (target.dataset.action === "clinic-info" && target.dataset.clinic) {
      state.selectedClinicId = target.dataset.clinic;
      state.openClinicInfoId = state.openClinicInfoId === target.dataset.clinic ? null : target.dataset.clinic;
      render();
      return;
    }

    if (target.dataset.action === "gac-info" && target.dataset.gac) {
      state.selectedGacId = target.dataset.gac;
      state.openGacInfoId = state.openGacInfoId === target.dataset.gac ? null : target.dataset.gac;
      render();
      return;
    }

    if (target.dataset.gac) {
      state.selectedGacId = target.dataset.gac;
      state.openGacInfoId = null;
      render();
      return;
    }

    if (target.dataset.clinic) {
      state.selectedClinicId = target.dataset.clinic;
      state.openClinicInfoId = null;
      render();
      return;
    }

    if (target.dataset.route) {
      go(target.dataset.route);
    }
  });

  app.addEventListener("input", (event) => {
    if (event.target.id !== "clinic-search") return;

    state.clinicSearch = event.target.value;
    const query = event.target.value.trim().toLowerCase();
    let visibleCards = 0;
    app.querySelectorAll("[data-clinic-search]").forEach((element) => {
      const matches = element.dataset.clinicSearch.includes(query);
      element.hidden = !matches;
      if (matches && element.classList.contains("clinic-card")) visibleCards += 1;
    });

    const emptyState = document.getElementById("clinic-search-empty");
    if (emptyState) emptyState.hidden = visibleCards > 0;
  });

  app.addEventListener("change", (event) => {
    if (event.target.dataset.action === "consent") {
      state.consent = event.target.checked;
      render();
    }
  });

  loadData().finally(() => {
    render();
    window.setTimeout(() => go("login", { replace: true }), 1200);
  });
})();
