(function () {
  const fallbackData = {
    patient: {
      name: "John Tan",
      patientId: "S1234567A",
      bloodTest: {
        date: "2026-06-12",
        ldl: 6.2,
      },
    },
    clinics: [
      {
        id: "c1",
        name: "Tampines Family Medical Clinic",
        distance: 0.7,
        phone: "+65 6781 2200",
        position: [64, 27],
        hours: "Mon-Fri 8:00 AM-5:30 PM; Sat 8:30 AM-12:30 PM",
        availability: "FH referral reviews before 4:00 PM on weekdays",
        notes: "Call ahead for cholesterol and family-history review appointments",
      },
      {
        id: "c2",
        name: "EastCare GP Clinic",
        distance: 1.1,
        phone: "+65 6788 1040",
        position: [34, 38],
        hours: "Mon-Fri 9:00 AM-6:00 PM; Sat 9:00 AM-1:00 PM",
        availability: "Next GP review window: this afternoon",
        notes: "Teleconsult follow-up available after the first visit",
      },
      {
        id: "c3",
        name: "Bedok Central Medical",
        distance: 1.6,
        phone: "+65 6442 8890",
        position: [72, 58],
        hours: "Mon-Fri 8:30 AM-8:00 PM; Sat-Sun 9:00 AM-12:00 PM",
        availability: "Same-day referral review if submitted before 3:30 PM",
        notes: "Directions open the nearest entrance for mobility access",
      },
      {
        id: "c4",
        name: "Healthway Family Clinic",
        distance: 2.0,
        phone: "+65 6245 5531",
        position: [43, 70],
        hours: "Mon-Fri 8:00 AM-7:00 PM; Sat 8:00 AM-2:00 PM",
        availability: "FH referral nurse callback within 1 working day",
        notes: "Bring existing medicines or previous lipid results if available",
      },
      {
        id: "c5",
        name: "Sunrise GP Partners",
        distance: 2.4,
        phone: "+65 6636 7720",
        position: [22, 64],
        hours: "Mon-Fri 9:00 AM-5:00 PM; closed weekends",
        availability: "Referral reviews every weekday morning",
        notes: "Clinic can request family screening guidance after GP review",
      },
    ],
    gacs: [
      {
        id: "gac1",
        name: "National Heart Centre Singapore GAC",
        distance: 6.2,
        phone: "+65 6704 8000",
        position: [62, 30],
        hours: "Mon-Fri 8:30 AM-5:30 PM",
        availability: "FH genetic counselling appointments available next week",
        notes: "Bring the GP referral email and latest blood test result",
      },
      {
        id: "gac2",
        name: "Singapore General Hospital GAC",
        distance: 6.8,
        phone: "+65 6321 4377",
        position: [38, 45],
        hours: "Mon-Fri 8:00 AM-5:00 PM",
        availability: "Nearest appointment slot shown in the booking calendar",
        notes: "Family history information can be added during booking",
      },
      {
        id: "gac3",
        name: "Changi General Hospital GAC",
        distance: 8.4,
        phone: "+65 6850 3333",
        position: [72, 62],
        hours: "Mon-Fri 8:30 AM-5:00 PM",
        availability: "Phone booking and app booking supported",
        notes: "Suitable if you prefer an east-side appointment location",
      },
    ],
  };

  const state = {
    route: "splash",
    history: [],
    data: fallbackData,
    notificationVisible: false,
    inboxUnread: true,
    openFaq: null,
    consent: false,
    selectedClinicId: "c1",
    openClinicInfoId: null,
    selectedGacId: "gac1",
    openGacInfoId: null,
    referralStep: "submitted",
    selectedDate: "2026-07-20",
    selectedTime: "9:30 AM",
    reminderAnswered: null,
    bookingCheckAnswered: null,
  };

  const app = document.getElementById("app");

  const faqItems = [
    {
      title: "Why is my cholesterol high?",
      body:
        "Cholesterol may be affected by diet, medical conditions, medicines, and inherited risk. Some people have high LDL from birth even when they feel well.",
    },
    {
      title: "What is Familial Hypercholesterolaemia (FH)?",
      body:
        "FH is an inherited condition that can cause high LDL cholesterol from a young age. Early review helps families manage risk before symptoms appear.",
    },
    {
      title: "Why should I see my GP?",
      body:
        "Your GP can review your result, assess your family history, start appropriate care, and make a referral to a Genetic Assessment Clinic if needed.",
    },
    {
      title: "What happens next?",
      body:
        "If your result is above 5.5 mmol/L, HealthBuddy prompts you to ask your GP for a referral. Your GP emails the referral back to you, then you can call or book with a Genetic Assessment Clinic.",
    },
    {
      title: "Why early testing saves lives",
      body:
        "Finding FH early can help patients and relatives reduce future heart disease risk through timely treatment and family screening.",
    },
  ];

  const messages = [
    {
      id: "blood",
      title: "Blood Test Results Ready",
      subtitle: "Your blood test results are now available.",
      unread: true,
    },
    {
      id: "appt",
      title: "Appointment Reminder",
      subtitle: "Dental appointment on 15 July 2026.",
      unread: false,
    },
    {
      id: "rx",
      title: "Prescription Ready",
      subtitle: "Medicine collection is ready at Pharmacy.",
      unread: false,
    },
    {
      id: "campaign",
      title: "Health Campaign",
      subtitle: "Find out about preventive screening.",
      unread: false,
    },
  ];

  const services = [
    ["Appointment", "cal", "appointments"],
    ["Register & Track Queue", "queue", "home"],
    ["Payment", "dollar", "home"],
    ["Medicine", "rx", "home"],
    ["Test Results & Reports", "chart", "results"],
    ["Assessment", "heart", "home"],
    ["Admission", "bed", "home"],
    ["Profile", "person", "home"],
  ];

  const specialtyCare = [
    ["Stroke Care", "brain"],
    ["Senior Wellness", "care"],
    ["Pregnancy & Baby Care", "baby"],
  ];

  const healthChamp = [
    ["Blood Glucose", "drop", "home"],
    ["Blood Pressure", "bp", "home"],
    ["BMI", "bmi", "home"],
    ["Cholesterol", "chol", "results"],
  ];

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function formatDate(value) {
    return new Intl.DateTimeFormat("en-SG", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(value));
  }

  function formatDayBefore(value) {
    const date = new Date(value);
    date.setDate(date.getDate() - 1);
    return formatDate(date);
  }

  function ldlBand(ldl) {
    if (ldl < 5) return { label: "Within target", className: "green", color: "var(--hb-green)" };
    if (ldl <= 5.5) return { label: "Borderline", className: "yellow", color: "var(--hb-yellow)" };
    return { label: "High range", className: "red", color: "var(--hb-red)" };
  }

  function markerPosition(ldl) {
    const capped = Math.max(0, Math.min(ldl, 8));
    return (capped / 8) * 100;
  }

  function clinicMeta(clinic) {
    return {
      hours: clinic.hours || "Mon-Fri 9:00 AM-5:00 PM",
      availability: clinic.availability || "Referral review available on weekdays",
      notes: clinic.notes || "Call the clinic before visiting for the latest appointment availability",
    };
  }

  function gacMeta(gac) {
    return {
      hours: gac.hours || "Mon-Fri 9:00 AM-5:00 PM",
      availability: gac.availability || "GAC appointment availability is shown during booking",
      notes: gac.notes || "Bring your GP referral email to the appointment",
    };
  }

  async function loadData() {
    try {
      const [patientResponse, clinicResponse, gacResponse] = await Promise.all([
        fetch("data/patient.json"),
        fetch("data/clinics.json"),
        fetch("data/gacs.json"),
      ]);
      if (!patientResponse.ok || !clinicResponse.ok || !gacResponse.ok) return;
      const [patient, clinics, gacs] = await Promise.all([patientResponse.json(), clinicResponse.json(), gacResponse.json()]);
      state.data = { patient, clinics, gacs };
    } catch (_) {
      state.data = fallbackData;
    }
  }

  function go(route, options = {}) {
    if (!options.replace) state.history.push(state.route);
    state.route = route;
    render();
  }

  function back() {
    state.route = state.history.pop() || "home";
    render();
  }

  function topbar(title, backEnabled = true, action = "") {
    return `
      <header class="topbar">
        ${
          backEnabled
            ? `<button class="back" data-action="back" aria-label="Go back">&lt;</button>`
            : `<span class="topbar-spacer"></span>`
        }
        <h1>${escapeHtml(title)}</h1>
        ${action || `<span class="topbar-spacer"></span>`}
      </header>
    `;
  }

  function bottomTabs(active) {
    const unread = state.inboxUnread ? `<span class="badge">1</span>` : "";
    return `
      <nav class="bottom-tabs" aria-label="HealthBuddy navigation">
        <button class="tab ${active === "home" ? "active" : ""}" data-route="home">
          <span class="tab-symbol home-tab"></span><span>Home</span>
        </button>
        <button class="tab ${active === "results" ? "active" : ""}" data-route="results">
          <span class="tab-symbol downloads-tab"></span><span>Downloads</span>
        </button>
        <button class="tab" data-route="home">
          <span class="tab-symbol favourite-tab"></span><span>Favourites</span>
        </button>
        <button class="tab ${active === "inbox" ? "active" : ""}" data-route="inbox">
          <span class="tab-symbol notes-tab"></span>${unread}<span>Notes</span>
        </button>
        <button class="tab ${active === "security" ? "active" : ""}" data-route="security">
          <span class="tab-symbol more-tab"></span><span>More</span>
        </button>
      </nav>
    `;
  }

  function healthBuddyLogo() {
    return `
      <span class="hb-logo-text" aria-label="HealthBuddy">
        <span class="health-word">Health</span><span class="buddy-word">Buddy</span>
      </span>
    `;
  }

  function serviceTile(title, icon, route, extraClass = "") {
    return `
      <button class="service-tile ${extraClass}" data-route="${route}">
        <span class="service-icon icon-${escapeHtml(icon)}"></span>
        <span>${escapeHtml(title)}</span>
      </button>
    `;
  }

  function splashScreen() {
    return `
      <section class="splash">
        <div class="splash-card">
          <div class="splash-app-icon">
            <span class="splash-heart"></span>
          </div>
          ${healthBuddyLogo()}
          <p>Your health is in your hands</p>
          <div class="singhealth-brand">SingHealth</div>
          <div class="hospital-grid" aria-label="SingHealth institutions">
            <span>Singapore General Hospital</span>
            <span>Changi General Hospital</span>
            <span>Sengkang General Hospital</span>
            <span>KK Women's and Children's Hospital</span>
            <span>National Heart Centre Singapore</span>
            <span>National Cancer Centre Singapore</span>
            <span>Singapore National Eye Centre</span>
            <span>SingHealth Polyclinics</span>
          </div>
          <div class="loader" aria-hidden="true"></div>
        </div>
      </section>
    `;
  }

  function loginScreen() {
    return `
      <section class="screen">
        <div class="login-hero">
          <div class="brand-row">
            <span class="singpass-mark">SP</span>
            <span>
              <span class="brand-title">SingPass</span>
              <span class="brand-subtitle">Secure access to HealthBuddy</span>
            </span>
          </div>
          <h1>Log in securely</h1>
          <p>Use your SingPass credentials to continue to SingHealth HealthBuddy.</p>
        </div>
        <div class="form-card">
          <div class="field">
            <label for="username">Username</label>
            <input id="username" value="S1234567A" autocomplete="username" />
          </div>
          <div class="field">
            <label for="password">Password</label>
            <input id="password" value="healthbuddy" type="password" autocomplete="current-password" />
          </div>
          <div class="face-row">
            <button class="secondary" data-action="face">Face ID</button>
            <button class="ghost" data-action="forgot">Forgot Password</button>
          </div>
          <button class="primary full" data-action="login">Log in</button>
        </div>
      </section>
    `;
  }

  function homeScreen() {
    const patient = state.data.patient;
    const ldlHigh = patient.bloodTest.ldl > 5.5;
    const notification = state.notificationVisible
      ? `
        <button class="notification pulse" data-route="inbox">
          <span class="notification-dot">!</span>
          <span>
            <strong>Your blood test results are now available.</strong>
            <span>Tap to open Inbox</span>
          </span>
        </button>
      `
      : "";
    const fhBrochure = ldlHigh
      ? `
        <section class="fh-brochure-card">
          <span class="fh-icon">FH</span>
          <span>
            <strong>FH risk guide</strong>
            <span>Your cholesterol indicator is above 5.5 mmol/L. Familial Hypercholesterolaemia can run in families, and early testing can reduce future heart risk.</span>
          </span>
          <button class="primary compact" data-route="results">View result</button>
        </section>
      `
      : "";
    return `
      <section class="screen">
        <header class="home-header">
          <button class="inbox-shortcut ${state.inboxUnread ? "pulse" : ""}" data-route="inbox" aria-label="Inbox">
            <span class="line-icon" aria-hidden="true"></span>
            ${state.inboxUnread ? `<span class="badge">1</span>` : ""}
          </button>
          ${healthBuddyLogo()}
          <button class="login-link" data-route="security">Log In</button>
        </header>
        <div class="content home-content">
          ${notification}
          ${fhBrochure}
          <section class="campaign-banner">
            <span class="banner-figure left"></span>
            <span>
              <strong>THE ALL NEW HEALTH CHAMP!</strong>
              <em>Keep track of your health records and personalised goals.</em>
            </span>
            <span class="banner-figure right"></span>
          </section>
          <div class="carousel-dots" aria-hidden="true"><span></span><span></span><span class="active"></span><span></span><span></span></div>
          <div class="section-title">
            <h2>Services</h2>
            <button class="see-all" data-route="results">See all &gt;</button>
          </div>
          <div class="service-grid">
            ${services.map(([title, icon, route]) => serviceTile(title, icon, route)).join("")}
          </div>
          <div class="section-title">
            <h2>Specialty Care</h2>
            <button class="see-all" data-route="results">See all &gt;</button>
          </div>
          <div class="specialty-strip">
            ${specialtyCare.map(([title, icon]) => serviceTile(title, icon, "home", "pill-tile")).join("")}
          </div>
          <div class="section-title">
            <h2>Health Champ</h2>
            <button class="see-all" data-route="results">See all &gt;</button>
          </div>
          <div class="champ-grid">
            ${healthChamp.map(([title, icon, route]) => serviceTile(title, icon, route, title === "Cholesterol" ? "alert-tile" : "")).join("")}
          </div>
          <div class="fh-journey-card">
            <span class="fh-icon">FH</span>
            <span>
              <strong>FH referral support</strong>
              <span>Hello, ${escapeHtml(patient.name.split(" ")[0])}. HealthBuddy can guide you from result review to GP referral and GAC booking.</span>
            </span>
            <button class="see-all" data-route="results">Open</button>
          </div>
        </div>
        ${bottomTabs("home")}
      </section>
    `;
  }

  function inboxScreen() {
    return `
      <section class="screen">
        ${topbar("Inbox", true)}
        <div class="content">
          <div class="section-title">
            <h2>Recent messages</h2>
            <span class="status-pill">Newest first</span>
          </div>
          ${messages
            .map((message) => {
              const unread = message.unread && state.inboxUnread;
              return `
                <button class="message-card ${unread ? "unread" : ""}" data-message="${message.id}">
                  <span class="${unread ? "unread-dot" : ""}"></span>
                  <span>
                    <strong>${escapeHtml(message.title)}</strong>
                    <span>${escapeHtml(message.subtitle)}</span>
                  </span>
                  ${unread ? `<span class="new-pill">NEW</span>` : `<span class="muted">&gt;</span>`}
                </button>
              `;
            })
            .join("")}
        </div>
        ${bottomTabs("inbox")}
      </section>
    `;
  }

  function resultsScreen() {
    const patient = state.data.patient;
    const ldl = patient.bloodTest.ldl;
    const band = ldlBand(ldl);
    const position = markerPosition(ldl);
    const shouldPromptReferral = ldl > 5.5;
    return `
      <section class="screen">
        ${topbar("Blood Test Results", true, `<button class="round-action" data-route="security" aria-label="Security">S</button>`)}
        <div class="content">
          <div class="gauge-card">
            <div class="gauge-heading">
              <span>
                <h2>Cholesterol indicator</h2>
                <p>Result date: ${formatDate(patient.bloodTest.date)}. HealthBuddy scans this against the FH referral threshold.</p>
              </span>
              <span class="gauge-status" style="background:${band.color}">${escapeHtml(band.label)}</span>
            </div>
            <div class="gauge" aria-label="LDL cholesterol visual indicator">
              <div class="gauge-marker" style="--pos:${position}%"></div>
              <div class="gauge-track"><span></span><span></span><span></span></div>
              <div class="gauge-labels">
                <span>Green 0.0-5.0 mmol/L</span>
                <span>Yellow 5.0-5.5</span>
                <span>Red 5.5+</span>
              </div>
            </div>
            <div class="care-note">
              ${
                shouldPromptReferral
                  ? "Your result is above 5.5 mmol/L, so HealthBuddy recommends asking your GP for a referral for FH testing."
                  : "Your result is not above the FH referral prompt threshold in this prototype."
              }
            </div>
          </div>
          <div class="section-title">
            <h2>Understand your result</h2>
          </div>
          ${faqItems.map((item, index) => faqCard(item, index)).join("")}
        </div>
        ${
          shouldPromptReferral
            ? `<div class="floating-referral"><button class="primary full" data-route="consent">Ask GP for Referral</button></div>`
            : ""
        }
        ${bottomTabs("results")}
      </section>
    `;
  }

  function faqCard(item, index) {
    const open = state.openFaq === index;
    return `
      <article class="faq-card ${open ? "open" : ""}">
        <button class="faq-toggle" data-faq="${index}" aria-expanded="${open}">
          <span class="faq-icon">i</span>
          <strong>${escapeHtml(item.title)}</strong>
          <span class="chevron">${open ? "-" : "+"}</span>
        </button>
        <div class="faq-body">
          <p>${escapeHtml(item.body)}</p>
          <div class="illustration" aria-hidden="true"><span class="illustration-line"></span></div>
          <button class="secondary" data-action="learn">Learn More</button>
        </div>
      </article>
    `;
  }

  function consentScreen() {
    return `
      <section class="screen">
        ${topbar("Share Blood Test Results")}
        <div class="content no-tabs">
          <div class="consent-box">
            <h2>Share Blood Test Results</h2>
            <p>
              By submitting this request, you authorise SingHealth to securely share your relevant laboratory results with your selected GP clinic through approved healthcare systems for clinical review.
            </p>
            <label class="check-row">
              <input type="checkbox" data-action="consent" ${state.consent ? "checked" : ""} />
              <span>I understand and consent.</span>
            </label>
            <button class="primary full" data-route="find-gp" ${state.consent ? "" : "disabled"}>Continue</button>
          </div>
        </div>
      </section>
    `;
  }

  function findGpScreen() {
    const clinics = state.data.clinics
      .slice()
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 5);
    return `
      <section class="screen">
        ${topbar("Ask GP for Referral")}
        <div class="content no-tabs">
          <div class="care-note">
            Call your GP and ask for an FH testing referral. Once your GP emails the referral back to you, HealthBuddy can help you book with a Genetic Assessment Clinic.
          </div>
          <div class="field">
            <label for="clinic-search">Search GP clinic to call</label>
            <input id="clinic-search" class="search-input" value="" placeholder="Search GP clinic" />
          </div>
          <button class="secondary full" data-action="locate">Use existing location services</button>
          <div class="section-title">
            <h2>Nearby GP clinics</h2>
            <span class="muted">Nearest five</span>
          </div>
          <div class="map-card" aria-label="Interactive map with nearby GP pins">
            <span class="map-road one"></span>
            <span class="map-road two"></span>
            <span class="location-dot" title="Your location"></span>
            ${clinics
              .map(
                (clinic, index) => `
                  <button class="map-pin ${clinic.id === state.selectedClinicId ? "selected" : ""}" style="left:${clinic.position[0]}%;top:${clinic.position[1]}%" data-clinic="${clinic.id}" aria-label="${escapeHtml(clinic.name)}">
                    <span>${index + 1}</span>
                  </button>
                `,
              )
              .join("")}
          </div>
          ${clinics.map((clinic) => clinicCard(clinic)).join("")}
          <button class="primary full" data-route="gp-referral-email">I have asked my GP</button>
        </div>
      </section>
    `;
  }

  function clinicCard(clinic) {
    const selected = clinic.id === state.selectedClinicId;
    const detailsOpen = clinic.id === state.openClinicInfoId;
    const details = clinicMeta(clinic);
    return `
      <article class="clinic-card ${selected ? "selected" : ""}">
        <div class="clinic-top">
          <span>
            <h3>${escapeHtml(clinic.name)}</h3>
            <p>${clinic.distance.toFixed(1)} km away - ${escapeHtml(clinic.phone)}</p>
          </span>
          ${selected ? `<span class="status-pill">Chosen</span>` : ""}
        </div>
        <div class="clinic-actions">
          <button class="mini-button" data-action="call" data-clinic="${clinic.id}">Call</button>
          <button class="mini-button" data-action="directions" data-clinic="${clinic.id}">Directions</button>
          <button class="mini-button" data-action="clinic-info" data-clinic="${clinic.id}">${detailsOpen ? "Hide info" : "Info"}</button>
        </div>
        ${
          detailsOpen
            ? `<div class="clinic-details">
                <span><strong>Opening hours</strong>${escapeHtml(details.hours)}</span>
                <span><strong>Referral availability</strong>${escapeHtml(details.availability)}</span>
                <span><strong>Clinic note</strong>${escapeHtml(details.notes)}</span>
              </div>`
            : ""
        }
      </article>
    `;
  }

  function gpReferralEmailScreen() {
    return `
      <section class="screen">
        ${topbar("GP Referral Email")}
        <div class="content no-tabs">
          <button class="notification full" data-action="noop">
            <span class="notification-dot">!</span>
            <span>
              <strong>Your GP has emailed your FH referral.</strong>
              <span>Referral ready for GAC booking</span>
            </span>
          </button>
          <div class="care-note">
            You can call a Genetic Assessment Clinic yourself, or use HealthBuddy to find the nearest GAC and book through the app.
          </div>
          ${timeline(["Blood Result Scanned", "GP Referral Requested", "Referral Email Received"], ["GAC Booking", "Appointment Reminders"])}
          <button class="primary full" data-route="find-gac">Find nearest GAC</button>
          <button class="secondary full" data-route="booking-check">Show 3-day booking check</button>
        </div>
      </section>
    `;
  }

  function bookingCheckScreen() {
    return `
      <section class="screen">
        ${topbar("GAC Booking Check")}
        <div class="content no-tabs">
          <button class="notification full" data-action="noop">
            <span class="notification-dot">!</span>
            <span>
              <strong>Have you made a booking with the GAC?</strong>
              <span>Simulated 3-day phone notification</span>
            </span>
          </button>
          <div class="care-note">
            If you already called the GAC yourself, confirm here and the app will close the loop. If not, HealthBuddy will show nearby GAC options.
          </div>
          <div class="reminder-actions">
            <button class="primary" data-action="booking-check-yes">Yes</button>
            <button class="secondary" data-action="booking-check-no">No</button>
          </div>
        </div>
      </section>
    `;
  }

  function selfBookedCompleteScreen() {
    return `
      <section class="screen">
        <div class="success-panel">
          <div class="tick" aria-hidden="true"></div>
          <span>
            <h1>GAC Booking Confirmed</h1>
            <p>You confirmed that you booked with the Genetic Assessment Clinic yourself. The referral loop is complete.</p>
          </span>
          ${timeline(["Blood Result Scanned", "GP Referral Requested", "Referral Email Received", "GAC Booking Confirmed"], [])}
          <button class="primary full" data-route="home">Back to Home</button>
        </div>
      </section>
    `;
  }

  function findGacScreen() {
    const gacs = (state.data.gacs || fallbackData.gacs)
      .slice()
      .sort((a, b) => a.distance - b.distance);
    return `
      <section class="screen">
        ${topbar("Find GAC")}
        <div class="content no-tabs">
          <div class="care-note">
            Choose a nearby Genetic Assessment Clinic to book your FH testing appointment. You can also call a clinic directly if you prefer.
          </div>
          <div class="section-title">
            <h2>Nearby GAC locations</h2>
            <span class="muted">Nearest first</span>
          </div>
          <div class="map-card" aria-label="Interactive map with nearby GAC pins">
            <span class="map-road one"></span>
            <span class="map-road two"></span>
            <span class="location-dot" title="Your location"></span>
            ${gacs
              .map(
                (gac, index) => `
                  <button class="map-pin ${gac.id === state.selectedGacId ? "selected" : ""}" style="left:${gac.position[0]}%;top:${gac.position[1]}%" data-gac="${gac.id}" aria-label="${escapeHtml(gac.name)}">
                    <span>${index + 1}</span>
                  </button>
                `,
              )
              .join("")}
          </div>
          ${gacs.map((gac) => gacCentreCard(gac)).join("")}
          <button class="primary full" data-action="book-chosen-gac">Book at chosen GAC</button>
          <button class="secondary full" data-route="self-booked-complete">I booked by calling GAC</button>
        </div>
      </section>
    `;
  }

  function gacCentreCard(gac) {
    const selected = gac.id === state.selectedGacId;
    const detailsOpen = gac.id === state.openGacInfoId;
    const details = gacMeta(gac);
    return `
      <article class="clinic-card ${selected ? "selected" : ""}">
        <div class="clinic-top">
          <span>
            <h3>${escapeHtml(gac.name)}</h3>
            <p>${gac.distance.toFixed(1)} km away - ${escapeHtml(gac.phone)}</p>
          </span>
          ${selected ? `<span class="status-pill">Chosen</span>` : ""}
        </div>
        <div class="clinic-actions">
          <button class="mini-button" data-action="call-gac" data-gac="${gac.id}">Call</button>
          <button class="mini-button" data-action="directions-gac" data-gac="${gac.id}">Directions</button>
          <button class="mini-button" data-action="gac-info" data-gac="${gac.id}">${detailsOpen ? "Hide info" : "Info"}</button>
        </div>
        ${
          detailsOpen
            ? `<div class="clinic-details">
                <span><strong>Opening hours</strong>${escapeHtml(details.hours)}</span>
                <span><strong>Appointment availability</strong>${escapeHtml(details.availability)}</span>
                <span><strong>Booking note</strong>${escapeHtml(details.notes)}</span>
              </div>`
            : ""
        }
      </article>
    `;
  }

  function submittedScreen() {
    return `
      <section class="screen">
        <div class="success-panel">
          <div class="tick" aria-hidden="true"></div>
          <span>
            <h1>Referral Request Sent</h1>
            <p>Your selected GP clinic has received your referral request.</p>
          </span>
          ${timeline(["Request Submitted"], ["GP Review", "Referral Created", "GAC Contact", "Appointment Booking"])}
          <button class="primary full" data-route="gp-review">View GP Review</button>
        </div>
      </section>
    `;
  }

  function gpReviewScreen() {
    const approved = state.referralStep === "approved";
    return `
      <section class="screen">
        ${topbar("GP Review Status")}
        <div class="content no-tabs">
          <div class="review-card">
            ${approved ? "" : `<div class="spinner" aria-hidden="true"></div>`}
            <h2>${approved ? "GP Approved" : "GP review in progress"}</h2>
            <p>${approved ? "Your GP has reviewed the result and sent a referral to the Genetic Assessment Clinic." : "This demonstration simulates your GP reviewing the request and approving the referral."}</p>
          </div>
          ${timeline(approved ? ["Request Submitted", "GP Approved", "Referral Sent to GAC"] : ["Request Submitted"], approved ? [] : ["GP Review", "Referral Created", "GAC Contact"])}
          ${
            approved
              ? `<button class="primary full" data-route="gac-notification">View GAC notification</button>`
              : `<button class="primary full" data-action="approve">Simulate GP Approval</button>`
          }
        </div>
      </section>
    `;
  }

  function gacNotificationScreen() {
    return `
      <section class="screen">
        ${topbar("GAC Notification")}
        <div class="content no-tabs">
          <button class="notification full" data-action="noop">
            <span class="notification-dot">!</span>
            <span>
              <strong>Your GP referral has been sent to the Genetic Assessment Clinic.</strong>
              <span>Timed update after GP approval</span>
            </span>
          </button>
          <div class="care-note">
            GP action is complete. Please look out for a call or SMS from the Genetic Assessment Clinic so they can confirm your next appointment.
          </div>
          ${timeline(["Request Submitted", "GP Approved", "Referral Sent to GAC"], ["GAC Contact", "Appointment Booking"])}
          <button class="primary full" data-route="gac">Continue to GAC update</button>
        </div>
      </section>
    `;
  }

  function gacScreen() {
    return `
      <section class="screen">
        <div class="success-panel">
          <div class="tick" aria-hidden="true"></div>
          <span>
            <h1>Referral Accepted</h1>
            <p>Your referral has been received by the Genetic Assessment Clinic.</p>
          </span>
          ${timeline(["Request Submitted", "GP Approved", "Referral Sent to GAC", "GAC Contact"], ["Appointment Booking"])}
          <button class="primary full" data-route="booking">Book Appointment</button>
        </div>
      </section>
    `;
  }

  function bookingScreen() {
    const gacs = state.data.gacs || fallbackData.gacs;
    const selectedGac = gacs.find((gac) => gac.id === state.selectedGacId) || gacs[0];
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const dates = [
      null,
      null,
      "2026-07-15",
      "2026-07-16",
      "2026-07-17",
      null,
      null,
      "2026-07-20",
      "2026-07-21",
      "2026-07-22",
      "2026-07-23",
      "2026-07-24",
      null,
      null,
    ];
    const times = ["9:30 AM", "10:45 AM", "2:15 PM", "4:00 PM"];
    return `
      <section class="screen">
        ${topbar("Book GAC Appointment")}
        <div class="content no-tabs">
          <div class="booking-card">
            <div class="section-title" style="margin-top:0">
              <h2>${escapeHtml(selectedGac.name)}</h2>
            </div>
            <p class="muted">GP referral email attached. Choose an appointment slot for FH testing.</p>
          </div>
          <div class="calendar">
            <strong>July 2026</strong>
            <div class="calendar-grid">
              ${days.map((day) => `<span class="day-label">${day}</span>`).join("")}
              ${dates
                .map((date) => {
                  if (!date) return `<span class="date-button"></span>`;
                  const day = new Date(date).getDate();
                  return `<button class="date-button available ${state.selectedDate === date ? "selected" : ""}" data-date="${date}">${day}</button>`;
                })
                .join("")}
            </div>
          </div>
          <div class="booking-card">
            <div class="section-title" style="margin-top:0">
              <h2>Available time slots</h2>
            </div>
            <div class="time-slots">
              ${times.map((time) => `<button class="time-slot ${state.selectedTime === time ? "selected" : ""}" data-time="${time}">${time}</button>`).join("")}
            </div>
          </div>
          <button class="primary full" data-route="appointment-confirmed">Book Appointment</button>
        </div>
      </section>
    `;
  }

  function appointmentConfirmedScreen() {
    return `
      <section class="screen">
        <div class="success-panel">
          <div class="tick" aria-hidden="true"></div>
          <span>
            <h1>Appointment Booked</h1>
            <p>Genetic Assessment Clinic appointment confirmed for ${formatDate(state.selectedDate)} at ${escapeHtml(state.selectedTime)}.</p>
          </span>
          ${timeline(["Blood Result Scanned", "GP Referral Email Received", "GAC Appointment Booked"], ["Appointment Reminders"])}
          <button class="secondary full" data-route="reminder">View Appointment Reminders</button>
          <button class="primary full" data-route="home">Back to Home</button>
        </div>
      </section>
    `;
  }

  function reminderScreen() {
    return `
      <section class="screen">
        ${topbar("Appointment Reminders")}
        <div class="content no-tabs">
          <button class="notification full" data-action="noop">
            <span class="notification-dot">!</span>
            <span>
              <strong>Your GAC appointment is tomorrow.</strong>
              <span>${formatDayBefore(state.selectedDate)} at ${escapeHtml(state.selectedTime)}</span>
            </span>
          </button>
          <button class="notification full" data-action="noop">
            <span class="notification-dot">!</span>
            <span>
              <strong>Your GAC appointment is today.</strong>
              <span>${formatDate(state.selectedDate)} at ${escapeHtml(state.selectedTime)}</span>
            </span>
          </button>
          <div class="care-note">
            HealthBuddy sends reminders the day before and the day of the Genetic Assessment Clinic appointment.
          </div>
          <button class="primary full" data-route="home">Back to Home</button>
        </div>
      </section>
    `;
  }

  function securityScreen() {
    const items = [
      ["Encrypted storage", "Patient information is protected using encrypted storage and secure transmission."],
      ["SingPass authentication", "Access is tied to SingPass sign-in before showing HealthBuddy services."],
      ["Annual security testing", "The service is checked regularly to maintain security readiness."],
      ["No sensitive data stored directly on device", "The prototype demonstrates minimal local storage of sensitive health information."],
      ["Explicit consent before sharing", "Laboratory data is shared with a GP clinic only after the patient confirms consent."],
    ];
    return `
      <section class="screen">
        ${topbar("Security Information")}
        <div class="content">
          ${items
            .map(
              ([title, body]) => `
                <article class="security-card">
                  <span class="security-icon">S</span>
                  <span><strong>${escapeHtml(title)}</strong><span>${escapeHtml(body)}</span></span>
                </article>
              `,
            )
            .join("")}
        </div>
        ${bottomTabs("security")}
      </section>
    `;
  }

  function timeline(doneItems, pendingItems) {
    return `
      <div class="timeline">
        ${doneItems
          .map(
            (item) => `
              <div class="timeline-item done">
                <span class="timeline-dot"></span>
                <span>${escapeHtml(item)}</span>
              </div>
            `,
          )
          .join("")}
        ${pendingItems
          .map(
            (item) => `
              <div class="timeline-item">
                <span class="timeline-dot"></span>
                <span>${escapeHtml(item)}</span>
              </div>
            `,
          )
          .join("")}
      </div>
    `;
  }

  function render() {
    const routes = {
      splash: splashScreen,
      login: loginScreen,
      home: homeScreen,
      inbox: inboxScreen,
      results: resultsScreen,
      consent: consentScreen,
      "find-gp": findGpScreen,
      "gp-referral-email": gpReferralEmailScreen,
      "booking-check": bookingCheckScreen,
      "self-booked-complete": selfBookedCompleteScreen,
      "find-gac": findGacScreen,
      submitted: submittedScreen,
      "gp-review": gpReviewScreen,
      "gac-notification": gacNotificationScreen,
      gac: gacScreen,
      booking: bookingScreen,
      "appointment-confirmed": appointmentConfirmedScreen,
      reminder: reminderScreen,
      security: securityScreen,
    };
    app.innerHTML = (routes[state.route] || homeScreen)();
  }

  app.addEventListener("click", (event) => {
    const target = event.target.closest("button");
    if (!target) return;

    if (target.dataset.action === "back") {
      back();
      return;
    }

    if (target.dataset.action === "login" || target.dataset.action === "face") {
      state.notificationVisible = false;
      go("home");
      window.setTimeout(() => {
        state.notificationVisible = true;
        if (state.route === "home") render();
      }, 900);
      return;
    }

    if (target.dataset.action === "forgot") {
      target.textContent = "Recovery link sent";
      return;
    }

    if (target.dataset.message === "blood") {
      state.inboxUnread = false;
      go("results");
      return;
    }

    if (target.dataset.message) {
      target.querySelector("strong").textContent = "Message opened";
      return;
    }

    if (target.dataset.faq !== undefined) {
      const index = Number(target.dataset.faq);
      state.openFaq = state.openFaq === index ? null : index;
      render();
      return;
    }

    if (target.dataset.action === "learn") {
      window.open("https://www.singhealth.com.sg/patient-care/conditions-treatments", "_blank", "noopener");
      return;
    }

    if (target.dataset.action === "submit-chosen-clinic") {
      go("gp-referral-email");
      return;
    }

    if (target.dataset.action === "booking-check-yes") {
      state.bookingCheckAnswered = "yes";
      go("self-booked-complete");
      return;
    }

    if (target.dataset.action === "booking-check-no") {
      state.bookingCheckAnswered = "no";
      go("find-gac");
      return;
    }

    if (target.dataset.action === "book-chosen-gac") {
      go("booking");
      return;
    }

    if (target.dataset.action === "clinic-info" && target.dataset.clinic) {
      state.selectedClinicId = target.dataset.clinic;
      state.openClinicInfoId = state.openClinicInfoId === target.dataset.clinic ? null : target.dataset.clinic;
      render();
      return;
    }

    if (target.dataset.action === "call" && target.dataset.clinic) {
      state.selectedClinicId = target.dataset.clinic;
      target.textContent = "Calling";
      return;
    }

    if (target.dataset.action === "directions" && target.dataset.clinic) {
      state.selectedClinicId = target.dataset.clinic;
      target.textContent = "Route";
      return;
    }

    if (target.dataset.action === "gac-info" && target.dataset.gac) {
      state.selectedGacId = target.dataset.gac;
      state.openGacInfoId = state.openGacInfoId === target.dataset.gac ? null : target.dataset.gac;
      render();
      return;
    }

    if (target.dataset.action === "call-gac" && target.dataset.gac) {
      state.selectedGacId = target.dataset.gac;
      target.textContent = "Calling";
      return;
    }

    if (target.dataset.action === "directions-gac" && target.dataset.gac) {
      state.selectedGacId = target.dataset.gac;
      target.textContent = "Route";
      return;
    }

    if (target.dataset.gac) {
      state.selectedGacId = target.dataset.gac;
      state.openGacInfoId = null;
      render();
      return;
    }

    if (target.dataset.clinic) {
      state.selectedClinicId = target.dataset.clinic;
      state.openClinicInfoId = null;
      render();
      return;
    }

    if (target.dataset.action === "locate") {
      target.textContent = "Location found";
      return;
    }

    if (target.dataset.action === "approve") {
      state.referralStep = "approved";
      render();
      return;
    }

    if (target.dataset.action === "gac") {
      go("gac");
      return;
    }

    if (target.dataset.action === "reminder-yes") {
      state.reminderAnswered = "yes";
      render();
      return;
    }

    if (target.dataset.action === "reminder-no") {
      state.reminderAnswered = "no";
      render();
      return;
    }

    if (target.dataset.date) {
      state.selectedDate = target.dataset.date;
      render();
      return;
    }

    if (target.dataset.time) {
      state.selectedTime = target.dataset.time;
      render();
      return;
    }

    if (target.dataset.route) {
      const route = target.dataset.route;
      if (route === "appointments") {
        state.notificationVisible = true;
        go("home");
      } else {
        go(route);
      }
    }
  });

  app.addEventListener("change", (event) => {
    if (event.target.dataset.action === "consent") {
      state.consent = event.target.checked;
      render();
    }
  });

  loadData().finally(() => {
    render();
    window.setTimeout(() => go("login", { replace: true }), 1200);
  });
})();
