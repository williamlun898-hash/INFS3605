# HealthBuddy FH Referral Prototype

High-fidelity mobile web prototype extending the SingHealth HealthBuddy experience for Familial Hypercholesterolaemia (FH) referral journeys.

## What It Includes

- SingPass-style login
- HealthBuddy-style home screen
- Inbox and push notification simulation
- LDL-driven cholesterol gauge
- Expandable FH education cards
- FH risk prompt when the mock LDL result is above 5.5 mmol/L
- GP call flow for asking for an FH referral
- Simulated GP referral email
- 3-day GAC booking check notification
- Nearest GAC map, app booking flow, booking confirmation, and appointment reminders
- Security information screen
- Mock JSON data and sample Excel workbook

## Run Locally

Open `index.html` directly in a browser, or serve the folder with any static server.

Example:

```bash
python -m http.server 4173
```

Then visit:

```text
http://127.0.0.1:4173/index.html
```

## GitHub Pages

This project is static HTML, CSS, and JavaScript, so it can be published with GitHub Pages.

Use `index.html` as the entry point.

## Mock Data

The app uses:

- `data/patient.json`
- `data/clinics.json`
- `data/gacs.json`
- `data/sample_blood_tests.xlsx`

The LDL gauge reads the mock LDL value from the patient data and intentionally does not display the exact LDL number in the patient-facing screen.
