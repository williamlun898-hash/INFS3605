(function () {
  const fallbackData = {
    patient: {
      name: "John Tan",
      patientId: "S1234567A",
      bloodTest: {
        date: "2026-06-12",
        ldl: 6.2,
      },
    },
    clinics: [
      {
        id: "c1",
        name: "Tampines Family Medical Clinic",
        distance: 0.7,
        phone: "+65 6781 2200",
        position: [64, 27],
      },
      {
        id: "c2",
        name: "EastCare GP Clinic",
        distance: 1.1,
        phone: "+65 6788 1040",
        position: [34, 38],
      },
      {
        id: "c3",
        name: "Bedok Central Medical",
        distance: 1.6,
        phone: "+65 6442 8890",
        position: [72, 58],
      },
      {
        id: "c4",
        name: "Healthway Family Clinic",
        distance: 2.0,
        phone: "+65 6245 5531",
        position: [43, 70],
      },
      {
        id: "c5",
        name: "Sunrise GP Partners",
        distance: 2.4,
        phone: "+65 6636 7720",
        position: [22, 64],
      },
    ],
  };

  const state = {
    route: "splash",
    history: [],
    data: fallbackData,
    notificationVisible: false,
    inboxUnread: true,
    openFaq: null,
    consent: false,
    selectedClinicId: "c1",
    referralStep: "submitted",
    selectedDate: "2026-07-20",
    selectedTime: "9:30 AM",
    reminderAnswered: null,
  };

  const app = document.getElementById("app");

  const faqItems = [
    {
      title: "Why is my cholesterol high?",
      body:
        "Cholesterol may be affected by diet, medical conditions, medicines, and inherited risk. Some people have high LDL from birth even when they feel well.",
    },
    {
      title: "What is Familial Hypercholesterolaemia (FH)?",
      body:
        "FH is an inherited condition that can cause high LDL cholesterol from a young age. Early review helps families manage risk before symptoms appear.",
    },
    {
      title: "Why should I see my GP?",
      body:
        "Your GP can review your result, assess your family history, start appropriate care, and make a referral to a Genetic Assessment Clinic if needed.",
    },
    {
      title: "What happens next?",
      body:
        "After consent, your selected GP clinic receives the referral request. If the GP approves, the Genetic Assessment Clinic contacts you to arrange an appointment.",
    },
    {
      title: "Why early testing saves lives",
      body:
        "Finding FH early can help patients and relatives reduce future heart disease risk through timely treatment and family screening.",
    },
  ];

  const messages = [
    {
      id: "blood",
      title: "Blood Test Results Ready",
      subtitle: "Your blood test results are now available.",
      unread: true,
    },
    {
      id: "appt",
      title: "Appointment Reminder",
      subtitle: "Dental appointment on 15 July 2026.",
      unread: false,
    },
    {
      id: "rx",
      title: "Prescription Ready",
      subtitle: "Medicine collection is ready at Pharmacy.",
      unread: false,
    },
    {
      id: "campaign",
      title: "Health Campaign",
      subtitle: "Find out about preventive screening.",
      unread: false,
    },
  ];

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function formatDate(value) {
    return new Intl.DateTimeFormat("en-SG", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(value));
  }

  function ldlBand(ldl) {
    if (ldl < 5) return { label: "Within target", className: "green", color: "var(--hb-green)" };
    if (ldl <= 5.5) return { label: "Borderline", className: "yellow", color: "var(--hb-yellow)" };
    return { label: "High range", className: "red", color: "var(--hb-red)" };
  }

  function markerPosition(ldl) {
    const capped = Math.max(0, Math.min(ldl, 8));
    return (capped / 8) * 100;
  }

  async function loadData() {
    try {
      const [patientResponse, clinicResponse] = await Promise.all([
        fetch("data/patient.json"),
        fetch("data/clinics.json"),
      ]);
      if (!patientResponse.ok || !clinicResponse.ok) return;
      const [patient, clinics] = await Promise.all([patientResponse.json(), clinicResponse.json()]);
      state.data = { patient, clinics };
    } catch (_) {
      state.data = fallbackData;
    }
  }

  function go(route, options = {}) {
    if (!options.replace) state.history.push(state.route);
    state.route = route;
    render();
  }

  function back() {
    state.route = state.history.pop() || "home";
    render();
  }

  function topbar(title, backEnabled = true, action = "") {
    return `
      <header class="topbar">
        ${
          backEnabled
            ? `<button class="back" data-action="back" aria-label="Go back">&lt;</button>`
            : `<span class="hb-mark">HB</span>`
        }
        <h1>${escapeHtml(title)}</h1>
        ${action}
      </header>
    `;
  }

  function bottomTabs(active) {
    const unread = state.inboxUnread ? `<span class="badge">1</span>` : "";
    return `
      <nav class="bottom-tabs" aria-label="HealthBuddy navigation">
        <button class="tab ${active === "home" ? "active" : ""}" data-route="home">
          <span class="tab-symbol">H</span><span>Home</span>
        </button>
        <button class="tab ${active === "results" ? "active" : ""}" data-route="results">
          <span class="tab-symbol">R</span><span>Results</span>
        </button>
        <button class="tab ${active === "inbox" ? "active" : ""}" data-route="inbox">
          <span class="tab-symbol">I</span>${unread}<span>Inbox</span>
        </button>
        <button class="tab ${active === "security" ? "active" : ""}" data-route="security">
          <span class="tab-symbol">S</span><span>Security</span>
        </button>
      </nav>
    `;
  }

  function splashScreen() {
    return `
      <section class="splash">
        <div class="splash-card">
          <div class="splash-logo">HB</div>
          <h1>HealthBuddy</h1>
          <p>SingHealth patient services</p>
          <div class="loader" aria-hidden="true"></div>
        </div>
      </section>
    `;
  }

  function loginScreen() {
    return `
      <section class="screen">
        <div class="login-hero">
          <div class="brand-row">
            <span class="singpass-mark">SP</span>
            <span>
              <span class="brand-title">SingPass</span>
              <span class="brand-subtitle">Secure access to HealthBuddy</span>
            </span>
          </div>
          <h1>Log in securely</h1>
          <p>Use your SingPass credentials to continue to SingHealth HealthBuddy.</p>
        </div>
        <div class="form-card">
          <div class="field">
            <label for="username">Username</label>
            <input id="username" value="S1234567A" autocomplete="username" />
          </div>
          <div class="field">
            <label for="password">Password</label>
            <input id="password" value="healthbuddy" type="password" autocomplete="current-password" />
          </div>
          <div class="face-row">
            <button class="secondary" data-action="face">Face ID</button>
            <button class="ghost" data-action="forgot">Forgot Password</button>
          </div>
          <button class="primary full" data-action="login">Log in</button>
        </div>
      </section>
    `;
  }

  function homeScreen() {
    const patient = state.data.patient;
    const notification = state.notificationVisible
      ? `
        <button class="notification pulse" data-route="inbox">
          <span class="notification-dot">!</span>
          <span>
            <strong>Your blood test results are now available.</strong>
            <span>Tap to open Inbox</span>
          </span>
        </button>
      `
      : "";
    const cards = [
      ["Appointments", "View and manage visits", "A", "appointments"],
      ["Test Results & Reports", "Laboratory and reports", "T", "results"],
      ["Medicines", "Active prescriptions", "M", "home"],
      ["Payments", "Bills and receipts", "$", "home"],
      ["Profile", "Personal details", "P", "home"],
      ["Inbox", state.inboxUnread ? "1 new message" : "Messages", "I", "inbox"],
    ];
    return `
      <section class="screen">
        <header class="home-header">
          <div class="brand-row">
            <span class="hb-mark">HB</span>
            <span>
              <span class="brand-title">HealthBuddy</span>
              <span class="brand-subtitle">SingHealth</span>
            </span>
          </div>
          <div class="hello">
            <span>
              <h1>Hello, ${escapeHtml(patient.name.split(" ")[0])}</h1>
              <p>Last signed in with SingPass</p>
            </span>
            <button class="inbox-shortcut ${state.inboxUnread ? "pulse" : ""}" data-route="inbox" aria-label="Inbox">
              <span class="line-icon" aria-hidden="true"></span>
              ${state.inboxUnread ? `<span class="badge">1</span>` : ""}
            </button>
          </div>
        </header>
        <div class="content">
          ${notification}
          <div class="section-title">
            <h2>Services</h2>
            <span class="muted">Today</span>
          </div>
          <div class="quick-grid">
            ${cards
              .map(
                ([title, subtitle, icon, route]) => `
                  <button class="quick-card" data-route="${route}">
                    <span class="quick-icon">${escapeHtml(icon)}</span>
                    <span>
                      <strong>${escapeHtml(title)}</strong>
                      <span>${escapeHtml(subtitle)}</span>
                    </span>
                  </button>
                `,
              )
              .join("")}
          </div>
          <div class="section-title">
            <h2>Referral journey</h2>
          </div>
          <div class="card care-note">
            Blood test results from hospital systems are available in HealthBuddy after SingPass authentication. You can review guidance and ask a GP clinic to assess a referral.
          </div>
        </div>
        ${bottomTabs("home")}
      </section>
    `;
  }

  function inboxScreen() {
    return `
      <section class="screen">
        ${topbar("Inbox", true)}
        <div class="content">
          <div class="section-title">
            <h2>Recent messages</h2>
            <span class="status-pill">Newest first</span>
          </div>
          ${messages
            .map((message) => {
              const unread = message.unread && state.inboxUnread;
              return `
                <button class="message-card ${unread ? "unread" : ""}" data-message="${message.id}">
                  <span class="${unread ? "unread-dot" : ""}"></span>
                  <span>
                    <strong>${escapeHtml(message.title)}</strong>
                    <span>${escapeHtml(message.subtitle)}</span>
                  </span>
                  ${unread ? `<span class="new-pill">NEW</span>` : `<span class="muted">&gt;</span>`}
                </button>
              `;
            })
            .join("")}
        </div>
        ${bottomTabs("inbox")}
      </section>
    `;
  }

  function resultsScreen() {
    const patient = state.data.patient;
    const ldl = patient.bloodTest.ldl;
    const band = ldlBand(ldl);
    const position = markerPosition(ldl);
    return `
      <section class="screen">
        ${topbar("Blood Test Results", true, `<button class="round-action" data-route="security" aria-label="Security">S</button>`)}
        <div class="content">
          <div class="gauge-card">
            <div class="gauge-heading">
              <span>
                <h2>Cholesterol indicator</h2>
                <p>Result date: ${formatDate(patient.bloodTest.date)}. The exact LDL number is not shown in this patient view.</p>
              </span>
              <span class="gauge-status" style="background:${band.color}">${escapeHtml(band.label)}</span>
            </div>
            <div class="gauge" aria-label="LDL cholesterol visual indicator">
              <div class="gauge-marker" style="--pos:${position}%"></div>
              <div class="gauge-track"><span></span><span></span><span></span></div>
              <div class="gauge-labels">
                <span>Green 0.0-5.0 mmol/L</span>
                <span>Yellow 5.0-5.5</span>
                <span>Red 5.5+</span>
              </div>
            </div>
            <div class="care-note">
              Your result falls in a range where follow-up with a GP is recommended. This prototype guides you through consent, GP selection, and Genetic Assessment Clinic booking.
            </div>
          </div>
          <div class="section-title">
            <h2>Understand your result</h2>
          </div>
          ${faqItems.map((item, index) => faqCard(item, index)).join("")}
        </div>
        <div class="floating-referral">
          <button class="primary full" data-route="consent">Ask GP for Referral</button>
        </div>
        ${bottomTabs("results")}
      </section>
    `;
  }

  function faqCard(item, index) {
    const open = state.openFaq === index;
    return `
      <article class="faq-card ${open ? "open" : ""}">
        <button class="faq-toggle" data-faq="${index}" aria-expanded="${open}">
          <span class="faq-icon">i</span>
          <strong>${escapeHtml(item.title)}</strong>
          <span class="chevron">${open ? "-" : "+"}</span>
        </button>
        <div class="faq-body">
          <p>${escapeHtml(item.body)}</p>
          <div class="illustration" aria-hidden="true"><span class="illustration-line"></span></div>
          <button class="secondary" data-action="learn">Learn More</button>
        </div>
      </article>
    `;
  }

  function consentScreen() {
    return `
      <section class="screen">
        ${topbar("Share Blood Test Results")}
        <div class="content no-tabs">
          <div class="consent-box">
            <h2>Share Blood Test Results</h2>
            <p>
              By submitting this request, you authorise SingHealth to securely share your relevant laboratory results with your selected GP clinic through approved healthcare systems for clinical review.
            </p>
            <label class="check-row">
              <input type="checkbox" data-action="consent" ${state.consent ? "checked" : ""} />
              <span>I understand and consent.</span>
            </label>
            <button class="primary full" data-route="find-gp" ${state.consent ? "" : "disabled"}>Continue</button>
          </div>
        </div>
      </section>
    `;
  }

  function findGpScreen() {
    const clinics = state.data.clinics
      .slice()
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 5);
    return `
      <section class="screen">
        ${topbar("Find GP")}
        <div class="content no-tabs">
          <div class="field">
            <label for="clinic-search">Search GP clinic</label>
            <input id="clinic-search" class="search-input" value="" placeholder="Search GP clinic" />
          </div>
          <button class="secondary full" data-action="locate">Use existing location services</button>
          <div class="section-title">
            <h2>Nearby clinics</h2>
            <span class="muted">Nearest five</span>
          </div>
          <div class="map-card" aria-label="Interactive map with nearby GP pins">
            <span class="map-road one"></span>
            <span class="map-road two"></span>
            <span class="location-dot" title="Your location"></span>
            ${clinics
              .map(
                (clinic, index) => `
                  <button class="map-pin ${clinic.id === state.selectedClinicId ? "selected" : ""}" style="left:${clinic.position[0]}%;top:${clinic.position[1]}%" data-clinic="${clinic.id}" aria-label="${escapeHtml(clinic.name)}">
                    <span>${index + 1}</span>
                  </button>
                `,
              )
              .join("")}
          </div>
          ${clinics.map((clinic) => clinicCard(clinic)).join("")}
        </div>
      </section>
    `;
  }

  function clinicCard(clinic) {
    const selected = clinic.id === state.selectedClinicId;
    return `
      <article class="clinic-card ${selected ? "selected" : ""}">
        <div class="clinic-top">
          <span>
            <h3>${escapeHtml(clinic.name)}</h3>
            <p>${clinic.distance.toFixed(1)} km away - ${escapeHtml(clinic.phone)}</p>
          </span>
          ${selected ? `<span class="status-pill">Selected</span>` : ""}
        </div>
        <div class="clinic-actions">
          <button class="mini-button" data-action="call" data-clinic="${clinic.id}">Call</button>
          <button class="mini-button" data-action="directions" data-clinic="${clinic.id}">Directions</button>
          <button class="mini-button" data-action="select-submit" data-clinic="${clinic.id}">Select</button>
        </div>
      </article>
    `;
  }

  function submittedScreen() {
    return `
      <section class="screen">
        <div class="success-panel">
          <div class="tick" aria-hidden="true"></div>
          <span>
            <h1>Referral Request Sent</h1>
            <p>Your selected GP clinic has received your referral request.</p>
          </span>
          ${timeline(["Request Submitted"], ["GP Review", "Referral Created", "GAC Contact", "Appointment Booking"])}
          <button class="primary full" data-route="gp-review">View GP Review</button>
        </div>
      </section>
    `;
  }

  function gpReviewScreen() {
    const approved = state.referralStep === "approved";
    return `
      <section class="screen">
        ${topbar("GP Review Status")}
        <div class="content no-tabs">
          <div class="review-card">
            ${approved ? "" : `<div class="spinner" aria-hidden="true"></div>`}
            <h2>${approved ? "GP Approved" : "GP review in progress"}</h2>
            <p>${approved ? "Your GP has reviewed the result and sent a referral to the Genetic Assessment Clinic." : "This demonstration simulates your GP reviewing the request and approving the referral."}</p>
          </div>
          ${timeline(approved ? ["Request Submitted", "GP Approved", "Referral Sent to GAC"] : ["Request Submitted"], approved ? [] : ["GP Review", "Referral Created", "GAC Contact"])}
          <button class="primary full" data-action="${approved ? "gac" : "approve"}">${approved ? "Continue" : "Simulate GP Approval"}</button>
        </div>
      </section>
    `;
  }

  function gacScreen() {
    return `
      <section class="screen">
        <div class="success-panel">
          <div class="tick" aria-hidden="true"></div>
          <span>
            <h1>Referral Accepted</h1>
            <p>Your referral has been received by the Genetic Assessment Clinic.</p>
          </span>
          ${timeline(["Request Submitted", "GP Approved", "Referral Sent to GAC", "GAC Contact"], ["Appointment Booking"])}
          <button class="primary full" data-route="booking">Book Appointment</button>
        </div>
      </section>
    `;
  }

  function bookingScreen() {
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const dates = [
      null,
      null,
      "2026-07-15",
      "2026-07-16",
      "2026-07-17",
      null,
      null,
      "2026-07-20",
      "2026-07-21",
      "2026-07-22",
      "2026-07-23",
      "2026-07-24",
      null,
      null,
    ];
    const times = ["9:30 AM", "10:45 AM", "2:15 PM", "4:00 PM"];
    return `
      <section class="screen">
        ${topbar("Book GAC Appointment")}
        <div class="content no-tabs">
          <div class="calendar">
            <strong>July 2026</strong>
            <div class="calendar-grid">
              ${days.map((day) => `<span class="day-label">${day}</span>`).join("")}
              ${dates
                .map((date) => {
                  if (!date) return `<span class="date-button"></span>`;
                  const day = new Date(date).getDate();
                  return `<button class="date-button available ${state.selectedDate === date ? "selected" : ""}" data-date="${date}">${day}</button>`;
                })
                .join("")}
            </div>
          </div>
          <div class="booking-card">
            <div class="section-title" style="margin-top:0">
              <h2>Available time slots</h2>
            </div>
            <div class="time-slots">
              ${times.map((time) => `<button class="time-slot ${state.selectedTime === time ? "selected" : ""}" data-time="${time}">${time}</button>`).join("")}
            </div>
          </div>
          <button class="primary full" data-route="appointment-confirmed">Book Appointment</button>
        </div>
      </section>
    `;
  }

  function appointmentConfirmedScreen() {
    return `
      <section class="screen">
        <div class="success-panel">
          <div class="tick" aria-hidden="true"></div>
          <span>
            <h1>Appointment Booked</h1>
            <p>Genetic Assessment Clinic appointment confirmed for ${formatDate(state.selectedDate)} at ${escapeHtml(state.selectedTime)}.</p>
          </span>
          ${timeline(["Request Submitted", "GP Approved", "Referral Sent to GAC", "GAC Contact", "Appointment Booking"], [])}
          <button class="secondary full" data-route="reminder">View Reminder Logic</button>
          <button class="primary full" data-route="home">Back to Home</button>
        </div>
      </section>
    `;
  }

  function reminderScreen() {
    const answered = state.reminderAnswered;
    return `
      <section class="screen">
        ${topbar("Reminder Notification")}
        <div class="content no-tabs">
          <button class="notification full" data-action="noop">
            <span class="notification-dot">!</span>
            <span>
              <strong>Have you contacted your GP regarding your cholesterol results?</strong>
              <span>Simulated 3-day reminder</span>
            </span>
          </button>
          ${
            answered === null
              ? `<div class="reminder-actions"><button class="primary" data-action="reminder-yes">Yes</button><button class="secondary" data-action="reminder-no">No</button></div>`
              : answered === "yes"
                ? `<div class="care-note">Please remember to answer calls from the Genetic Assessment Clinic.</div>`
                : `<div class="care-note">No problem. HealthBuddy can help you find a nearby GP clinic now.</div><button class="primary full" style="margin-top:14px" data-route="find-gp">Open Find GP</button>`
          }
        </div>
      </section>
    `;
  }

  function securityScreen() {
    const items = [
      ["Encrypted storage", "Patient information is protected using encrypted storage and secure transmission."],
      ["SingPass authentication", "Access is tied to SingPass sign-in before showing HealthBuddy services."],
      ["Annual security testing", "The service is checked regularly to maintain security readiness."],
      ["No sensitive data stored directly on device", "The prototype demonstrates minimal local storage of sensitive health information."],
      ["Explicit consent before sharing", "Laboratory data is shared with a GP clinic only after the patient confirms consent."],
    ];
    return `
      <section class="screen">
        ${topbar("Security Information")}
        <div class="content">
          ${items
            .map(
              ([title, body]) => `
                <article class="security-card">
                  <span class="security-icon">S</span>
                  <span><strong>${escapeHtml(title)}</strong><span>${escapeHtml(body)}</span></span>
                </article>
              `,
            )
            .join("")}
        </div>
        ${bottomTabs("security")}
      </section>
    `;
  }

  function timeline(doneItems, pendingItems) {
    return `
      <div class="timeline">
        ${doneItems
          .map(
            (item) => `
              <div class="timeline-item done">
                <span class="timeline-dot"></span>
                <span>${escapeHtml(item)}</span>
              </div>
            `,
          )
          .join("")}
        ${pendingItems
          .map(
            (item) => `
              <div class="timeline-item">
                <span class="timeline-dot"></span>
                <span>${escapeHtml(item)}</span>
              </div>
            `,
          )
          .join("")}
      </div>
    `;
  }

  function render() {
    const routes = {
      splash: splashScreen,
      login: loginScreen,
      home: homeScreen,
      inbox: inboxScreen,
      results: resultsScreen,
      consent: consentScreen,
      "find-gp": findGpScreen,
      submitted: submittedScreen,
      "gp-review": gpReviewScreen,
      gac: gacScreen,
      booking: bookingScreen,
      "appointment-confirmed": appointmentConfirmedScreen,
      reminder: reminderScreen,
      security: securityScreen,
    };
    app.innerHTML = (routes[state.route] || homeScreen)();
  }

  app.addEventListener("click", (event) => {
    const target = event.target.closest("button");
    if (!target) return;

    if (target.dataset.action === "back") {
      back();
      return;
    }

    if (target.dataset.action === "login" || target.dataset.action === "face") {
      state.notificationVisible = false;
      go("home");
      window.setTimeout(() => {
        state.notificationVisible = true;
        if (state.route === "home") render();
      }, 900);
      return;
    }

    if (target.dataset.action === "forgot") {
      target.textContent = "Recovery link sent";
      return;
    }

    if (target.dataset.message === "blood") {
      state.inboxUnread = false;
      go("results");
      return;
    }

    if (target.dataset.message) {
      target.querySelector("strong").textContent = "Message opened";
      return;
    }

    if (target.dataset.faq !== undefined) {
      const index = Number(target.dataset.faq);
      state.openFaq = state.openFaq === index ? null : index;
      render();
      return;
    }

    if (target.dataset.action === "learn") {
      window.open("https://www.singhealth.com.sg/patient-care/conditions-treatments", "_blank", "noopener");
      return;
    }

    if (target.dataset.clinic) {
      state.selectedClinicId = target.dataset.clinic;
      if (target.dataset.action === "select-submit") {
        go("submitted");
      } else {
        render();
      }
      return;
    }

    if (target.dataset.action === "locate") {
      target.textContent = "Location found";
      return;
    }

    if (target.dataset.action === "call") {
      target.textContent = "Calling";
      return;
    }

    if (target.dataset.action === "directions") {
      target.textContent = "Route";
      return;
    }

    if (target.dataset.action === "approve") {
      state.referralStep = "approved";
      render();
      return;
    }

    if (target.dataset.action === "gac") {
      go("gac");
      return;
    }

    if (target.dataset.action === "reminder-yes") {
      state.reminderAnswered = "yes";
      render();
      return;
    }

    if (target.dataset.action === "reminder-no") {
      state.reminderAnswered = "no";
      render();
      return;
    }

    if (target.dataset.date) {
      state.selectedDate = target.dataset.date;
      render();
      return;
    }

    if (target.dataset.time) {
      state.selectedTime = target.dataset.time;
      render();
      return;
    }

    if (target.dataset.route) {
      const route = target.dataset.route;
      if (route === "appointments") {
        state.notificationVisible = true;
        go("home");
      } else {
        go(route);
      }
    }
  });

  app.addEventListener("change", (event) => {
    if (event.target.dataset.action === "consent") {
      state.consent = event.target.checked;
      render();
    }
  });

  loadData().finally(() => {
    render();
    window.setTimeout(() => go("login", { replace: true }), 1200);
  });
})();
