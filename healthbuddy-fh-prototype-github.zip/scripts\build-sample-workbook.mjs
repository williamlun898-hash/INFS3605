import fs from "node:fs/promises";
import path from "node:path";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = process.cwd();
const outputDir = path.join(root, "outputs", "healthbuddy-fh-prototype");
const dataDir = path.join(root, "data");

await fs.mkdir(outputDir, { recursive: true });
await fs.mkdir(dataDir, { recursive: true });

const rows = [
  ["Patient Name", "Patient ID", "Date", "LDL"],
  ["John Tan", "S1234567A", new Date("2026-06-12T00:00:00+08:00"), 6.2],
  ["Mary Lim", "S2345678B", new Date("2026-06-12T00:00:00+08:00"), 5.1],
  ["David Lee", "S4567890C", new Date("2026-06-12T00:00:00+08:00"), 3.8],
];

const workbook = Workbook.create();
const dataSheet = workbook.worksheets.add("Blood Test Data");
const codebook = workbook.worksheets.add("Codebook");

dataSheet.showGridLines = false;
dataSheet.getRange("A1:D4").values = rows;
dataSheet.getRange("A1:D1").format = {
  fill: "#1F8CCF",
  font: { bold: true, color: "#FFFFFF" },
};
dataSheet.getRange("A1:D4").format.borders = { preset: "outside", style: "thin", color: "#C8DCE8" };
dataSheet.getRange("A2:B4").format.numberFormat = "@";
dataSheet.getRange("C2:C4").setNumberFormat("d mmmm yyyy");
dataSheet.getRange("D2:D4").setNumberFormat("0.0");
dataSheet.getRange("A:D").format.autofitColumns();
dataSheet.freezePanes.freezeRows(1);

dataSheet.getRange("F1:G4").values = [
  ["LDL Legend", "Meaning"],
  ["<5.0 mmol/L", "Green"],
  ["5.0-5.5 mmol/L", "Yellow"],
  [">5.5 mmol/L", "Red"],
];
dataSheet.getRange("F1:G1").format = {
  fill: "#0AA6A6",
  font: { bold: true, color: "#FFFFFF" },
};
dataSheet.getRange("F1:G4").format.borders = { preset: "outside", style: "thin", color: "#C8DCE8" };
dataSheet.getRange("F:G").format.autofitColumns();

codebook.showGridLines = false;
codebook.getRange("A1:B7").values = [
  ["Field", "Definition"],
  ["Patient Name", "Mock patient name for demonstration only"],
  ["Patient ID", "Mock identifier for prototype testing"],
  ["Date", "Blood test result date"],
  ["LDL", "Low-density lipoprotein cholesterol in mmol/L"],
  ["Source", "Synthetic data created for local prototype"],
  ["Usage", "Frontend reads only the LDL column for gauge logic"],
];
codebook.getRange("A1:B1").format = {
  fill: "#1F8CCF",
  font: { bold: true, color: "#FFFFFF" },
};
codebook.getRange("A1:B7").format.borders = { preset: "outside", style: "thin", color: "#C8DCE8" };
codebook.getRange("A:B").format.autofitColumns();

const tableInspect = await workbook.inspect({
  kind: "table",
  range: "Blood Test Data!A1:D4",
  include: "values,formulas",
  tableMaxRows: 10,
  tableMaxCols: 6,
});
console.log(tableInspect.ndjson);

const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
});
console.log(errors.ndjson);

const preview = await workbook.render({
  sheetName: "Blood Test Data",
  autoCrop: "all",
  scale: 1,
  format: "png",
});
await fs.writeFile(path.join(outputDir, "sample_blood_tests_preview.png"), new Uint8Array(await preview.arrayBuffer()));

const output = await SpreadsheetFile.exportXlsx(workbook);
const workbookPath = path.join(outputDir, "sample_blood_tests.xlsx");
await output.save(workbookPath);
await fs.copyFile(workbookPath, path.join(dataDir, "sample_blood_tests.xlsx"));

console.log(`Saved ${workbookPath}`);
